import json
from zphi import *
from ring5x10 import U, g, apply, mpow, A, dot, perp, r2
C=json.load(open("ring5x10_cands.json"))
c=[x for x in C if x["n"]==40 and x["ov"]==10][0]
k,Q=c["k"],tuple(c["Q"])
gk=mpow(g,k); h=lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
units=[[tuple(u) for u in U]]
for _ in range(4): units.append([h(x) for x in units[-1]])
owner={}
for i,un in enumerate(units):
    for x in un: owner.setdefault(x,[]).append(i)
allc=sorted(owner)
# 芯（h の軸）: 軌道の和
o=[allc[0]]
for _ in range(4): o.append(h(o[-1]))
core=tuple(sum(x[t] for x in o) for t in range(6))          # 5倍した芯
def rc(x): return phys(tuple(5*x[t]-core[t] for t in range(6)))
print("芯からの水平距離²（種類と個数）、高さ")
from collections import Counter
cnt=Counter((r2(rc(x)), dot(phys(x),A)) for x in allc)
for kk,v in sorted(cnt.items(), key=lambda kv: float(kv[0][0].a+kv[0][0].b*1.618)): print("  ",kk,v)
print("食い込む組:")
for i in range(len(allc)):
    for j in range(i+1,len(allc)):
        if overlap(allc[i],allc[j]):
            a,b=allc[i],allc[j]
            print("  単位",owner[a],owner[b]," 高さ",dot(phys(a),A),dot(phys(b),A)," 差",tuple(a[t]-b[t] for t in range(6)))

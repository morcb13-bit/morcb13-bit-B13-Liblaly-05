import math, itertools
import q1_match as Q
P = Q.plane_points(Q.h_fig)
c = sum(Q.zf(p) for p in P) / len(P)
dP = min(abs(Q.zf(a) - Q.zf(b)) for a, b in itertools.combinations(P, 2))
dS = math.sqrt(Q.dmin)
s0 = sum(Q.zf(q) for q in Q.S) / len(Q.S)
RS = max(abs(Q.zf(q) - s0) for q in Q.S)
for rmax in (18, 30, 42):
    sub = [p for p in P if abs(Q.zf(p) - c) <= rmax]
    rad = max(abs(Q.zf(p) - c) for p in sub)
    print("切り口 半径 %d：五角形 %d 個、平面のペンローズの目盛りで半径 %.1f（平面のペンローズの範囲は半径 %.1f）" % (rmax, len(sub), rad * dS / dP, RS))
# 負の対照：119 個の集まりの 1 点を、隣の五角形 1 歩ぶんずらす
sub = [p for p in P if abs(Q.zf(p) - c) <= 30]
a, b = next((a, b) for a, b in itertools.permutations(sub, 2) if abs(abs(Q.zf(a) - Q.zf(b)) - dP) < 1e-9)
step = Q.zsub(b, a)
far = max(sub, key=lambda p: abs(Q.zf(p) - c))
bad = [p for p in sub if p != far] + [Q.zadd(far, Q.zmul(step, (0, 1, 0, 0)))]
Q.prepare(bad)
print("対照 1 点だけずらした 119 個 → 写し方", Q.match(bad))

"""色つきの 50 枚だけで P1 に重なる写し方と、その行き先の半径。そのうえで、つなぎの選び方 2^5 通り（各組で 2 枚おきを A 側か B 側か）を全部試す。"""
import itertools, math
from collections import Counter, defaultdict
import q1_match as Q
import bridge as Bm
import bridge2 as B2
s0 = sum(Q.zf(q) for q in Q.S) / len(Q.S)
def maps(pts):
    """pts を P1 に重ねる写し方を全部返す（(写し方の係数, 平行移動, 鏡映) の組）"""
    out = []
    dP = min(Q.n2(Q.zsub(a, b)) for a, b in itertools.combinations(pts, 2))
    p0, p1 = next((a, b) for a, b in itertools.permutations(pts, 2) if abs(Q.n2(Q.zsub(a, b)) - dP) < 1e-9)
    for refl in (False, True):
        PP = [Q.conj(x) for x in pts] if refl else pts
        a0, a1 = (Q.conj(p0), Q.conj(p1)) if refl else (p0, p1)
        e = Q.zsub(a1, a0); N = Q.zmul(e, Q.conj(e))
        if N not in Q.NS: Q.NS[N] = {Q.zmul(N, q) for q in Q.S}
        for q0, q1 in Q.adjS:
            k = Q.zmul(Q.zsub(q1, q0), Q.conj(e))
            if all(Q.zadd(Q.zmul(Q.zsub(p, a0), k), Q.zmul(N, q0)) in Q.NS[N] for p in PP):
                out.append((refl, a0, k, N, q0))
    return out
def image(m, p):
    refl, a0, k, N, q0 = m
    pp = Q.conj(p) if refl else p
    return Q.zadd(Q.zmul(Q.zsub(pp, a0), k), Q.zmul(N, q0))
col = [B2.div10(p) for p in Bm.colored]
M = maps(col)
rad = sorted(round(abs(Q.zf(image(m, col[0])) / Q.zf(m[3]) - s0), 1) for m in M)
print("色つき 50 枚だけ：P1 に重なる写し方 %d・行き先の半径（最小 %.1f、最大 %.1f）" % (len(M), rad[0], rad[-1]))
# 欠けのない範囲（半径 40 以内）に行く写し方だけ残す
Min = [m for m in M if abs(Q.zf(image(m, col[0])) / Q.zf(m[3]) - s0) < 40]
print("   そのうち行き先が半径 40 以内:", len(Min))
mixed = {}
for key, bs in B2.classes.items():
    if key[:2] in ((0, 2), (2, 0)):
        for a, b, c in bs: mixed.setdefault((a, b), {})[key[:2]] = c
pairs = sorted(mixed)
res = Counter()
for choice in itertools.product(((0, 2), (2, 0)), repeat=5):
    new = set()
    for pr, ch in zip(pairs, choice): new |= set(Bm.ring_at(mixed[pr][ch]))
    newp = [B2.div10(p) for p in new - Bm.colored]
    clash = Bm.overlap(list(new - Bm.colored), list(Bm.colored)) or Bm.overlap(list(new - Bm.colored), list(new - Bm.colored))
    ok = sum(1 for m in Min if all(image(m, p) in Q.NS[m[3]] for p in newp))
    res[(sum(1 for c in choice if c == (0, 2)), "食い込みあり" if clash else "なし", ok)] += 1
print("2 枚おきの向きを組ごとに選ぶ 32 通り：（B 側が 2 枚おきの組の数, 食い込み, 欠けのない範囲で P1 に重なる写し方）→ 件数")
for k, v in sorted(res.items()): print("  ", k, v)

"""ring5x10.py ── 30面体10個の輪（単位）を5個、五芒星を芯に並べる。
判定は Z[φ] の整数だけ。浮動小数は g の候補探しにも使わない。"""
import json, itertools
from zphi import *

U=[tuple(c) for c in json.load(open("kabai_ring.json"))["rings"]["10"]["centers6"]]
A=GEN[2]                               # 5回軸
AA=dot(A,A)
def perp(p): return tuple(AA*p[t]-dot(p,A)*A[t] for t in range(3))   # 軸に垂直な成分×(A·A)
def r2(p): q=perp(p); return dot(q,q)

# --- g：GEN[2] を軸とする 72° 回転を符号つき置換で探す（Gram 行列を保つもの）
G=[[dot(GEN[i],GEN[j]) for j in range(6)] for i in range(6)]
def apply(M,v): return tuple(sum(M[r][c]*v[c] for c in range(6)) for r in range(6))
cands=[]
for perm in itertools.permutations(range(6)):
    if perm[2]!=2: continue
    for sg in itertools.product((1,-1),repeat=6):
        if sg[2]!=1: continue
        M=[[0]*6 for _ in range(6)]
        for k in range(6): M[perm[k]][k]=sg[k]
        if all(G[perm[i]][perm[j]]*(sg[i]*sg[j])==G[i][j] for i in range(6) for j in range(6)):
            cands.append(M)
def mpow(M,k):
    R=[[int(r==c) for c in range(6)] for r in range(6)]
    for _ in range(k): R=[[sum(M[r][t]*R[t][c] for t in range(6)) for c in range(6)] for r in range(6)]
    return R
I=mpow(cands[0],0)
order5=[M for M in cands if mpow(M,5)==I and M!=I]
print("T0 軸 GEN[2] を保つ格子回転", len(cands), "個、そのうち位数5", len(order5))
# 単位の輪が自分に写る g（輪の5回対称）を採る
def ring_sym(M):
    S=set(U); 
    for Q in {tuple(b[t]-apply(M,a)[t] for t in range(6)) for a in U for b in U}:
        if all(tuple(apply(M,u)[t]+Q[t] for t in range(6)) in S for u in U): return Q
    return None
g=[M for M in order5 if ring_sym(M) is not None]
print("   単位の輪を自分に写す位数5の回転", len(g))
g=g[0]

# --- T1 単位：上下ジグザグか
hs=[dot(phys(u),A) for u in U]
hset=sorted(set(hs),key=lambda z:(z.sign(),)) 
print("T1 単位の中心の高さ（軸方向×|A|²）の種類:", set(hs))
# 輪の軸（単位の中心）からの水平距離
cen=[sum(u[t] for u in U) for t in range(6)]          # 10倍した重心
def rel(u): return phys(tuple(10*u[t]-cen[t] for t in range(6)))
print("   輪の軸からの水平距離²（×100·|A|⁴）の種類:", {r2(rel(u)) for u in U})
# 隣どうし（面接触）
nt=sum(touch(U[i],U[j]) for i in range(10) for j in range(i+1,10))
no=sum(overlap(U[i],U[j]) for i in range(10) for j in range(i+1,10))
print("   面接触の組", nt, " 食い込み", no)

# --- 5個並べる：h(x)=g^k x + Q
S5=[[sum(mpow(g,k)[r][c] for k in range(5)) for c in range(6)] for r in range(6)]
res=[]
for k in (1,2,3,4):
    gk=mpow(g,k)
    Qs={tuple(b[t]-apply(gk,a)[t] for t in range(6)) for a in U for b in U}
    for Q in Qs:
        if any(sum(S5[r][c]*Q[c] for c in range(6))!=0 for r in range(6)): continue  # 5回で元に戻る
        h=lambda x,gk=gk,Q=Q: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
        units=[U]
        for _ in range(4): units.append([h(x) for x in units[-1]])
        if set(units[-1] and [h(x) for x in units[-1]])!=set(U): continue
        if set(units[1])==set(U): continue     # 同じ輪に重なる（軸が同じ）
        share=[[len(set(units[i])&set(units[j])) for j in range(5)] for i in range(5)]
        allc=sorted(set(x for un in units for x in un))
        ov=sum(overlap(allc[i],allc[j]) for i in range(len(allc)) for j in range(i+1,len(allc)))
        res.append((k,Q,share[0][1],share[0][2],len(allc),ov,units))
print("\n候補（回転の段 k、隣と共有、一つ飛ばしと共有、30面体の数、食い込み）")
seen=set()
for k,Q,s1,s2,n,ov,un in sorted(res,key=lambda r:(r[5],r[4])):
    key=(k,s1,s2,n,ov)
    if key in seen: continue
    seen.add(key); print("  k=%d Q=%s 隣%d 飛%d 個数%d 食い込み%d"%(k,Q,s1,s2,n,ov))
json.dump([{"k":k,"Q":Q,"s1":s1,"s2":s2,"n":n,"ov":ov,"centers6":sorted(set(x for u in un for x in u))} for k,Q,s1,s2,n,ov,un in res],open("ring5x10_cands.json","w"))

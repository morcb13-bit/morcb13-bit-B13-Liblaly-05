"""図のためのデータを書き出す。判定は済んでいるので、ここでは座標を小数にするだけ。"""
import json, math
from zphi import *
import ring5x10 as R
U,g,apply,mpow,A=R.U,R.g,R.apply,R.mpow,R.A
PH=(1+5**.5)/2
f=lambda z: z.a+z.b*PH
def fv(v): return [f(x) for x in v]
Af=fv(A); nA=math.sqrt(sum(x*x for x in Af)); w=[x/nA for x in Af]
p=fv(GEN[0]); d=sum(p[i]*w[i] for i in range(3)); p=[p[i]-d*w[i] for i in range(3)]
n=math.sqrt(sum(x*x for x in p)); p=[x/n for x in p]
q=[w[1]*p[2]-w[2]*p[1], w[2]*p[0]-w[0]*p[2], w[0]*p[1]-w[1]*p[0]]
def frame(v): return [sum(v[i]*p[i] for i in range(3)), sum(v[i]*q[i] for i in range(3)), sum(v[i]*w[i] for i in range(3))]
# 30面体の面（中心からの相対、4頂点）
import itertools
faces=[]
G=[fv(x) for x in GEN]
for i,j in itertools.combinations(range(6),2):
    nv=fv(cross(GEN[i],GEN[j]))
    for s in (1,-1):
        nn=[s*x for x in nv]
        c=[0,0,0]
        for k in range(6):
            dd=sum(G[k][t]*nn[t] for t in range(3))
            if abs(dd)<1e-9: continue
            c=[c[t]+G[k][t]*(.5 if dd>0 else -.5) for t in range(3)]
        u=[x*.5 for x in G[i]]; v=[x*.5 for x in G[j]]
        quad=[[c[t]-u[t]-v[t] for t in range(3)],[c[t]+u[t]-v[t] for t in range(3)],
              [c[t]+u[t]+v[t] for t in range(3)],[c[t]-u[t]+v[t] for t in range(3)]]
        faces.append({"q":[[round(x,4) for x in frame(P)] for P in quad],"n":[round(x,4) for x in frame(nn)]})
def screw(k,Q):
    gk=mpow(g,k); return lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
def build(k,Q,nunits):
    h=screw(k,Q); us=[list(U)]
    for _ in range(nunits-1): us.append([h(x) for x in us[-1]])
    owner={}
    for i,un in enumerate(us):
        for x in un: owner.setdefault(x,[]).append(i)
    return us,owner
def pack(k,Q,nunits,flat=False):
    us,owner=build(k,Q,nunits)
    allc=sorted(owner)
    bad=set()
    for a,b in itertools.combinations(allc,2):
        if overlap(a,b): bad.add(a); bad.add(b)
    P={c:frame(fv(phys(c))) for c in allc}
    # 芯：最初の5単位の影の重心
    first=set(x for u in us[:5] for x in u)
    cx=sum(P[c][0] for c in first)/len(first); cy=sum(P[c][1] for c in first)/len(first)
    zs=[P[c][2] for c in allc]; cz=(max(zs)+min(zs))/2
    rts=[]
    for c in allc:
        o=owner[c]
        rts.append({"p":[round(P[c][0]-cx,4),round(P[c][1]-cy,4),round(P[c][2]-cz,4)],
                    "u":o[0],"s":len(o)>1,"x":c in bad,"o":o})
    return {"rts":rts,"n":len(allc),"bad":len(bad)//2 if flat else 0,"units":nunits}
H=json.load(open("helix5x10.json"))
F=[o for o in json.load(open("ring5x10_cands.json")) if o["n"]==40 and o["ov"]==10]
t1=[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==1 and f(Z(*o["pitch"]))>0][0]
t2=[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==2 and f(Z(*o["pitch"]))>0][0]
fl=F[0]
D={"faces":faces,
   "flat":pack(fl["k"],tuple(fl["Q"]),5,True),
   "t1":pack(t1["k"],tuple(t1["Q"]),10),
   "t2":pack(t2["k"],tuple(t2["Q"]),10)}
for k in ("flat","t1","t2"): print(k,D[k]["n"],"食い込みに関わる",sum(r["x"] for r in D[k]["rts"]))
json.dump(D,open("fig_data.json","w"),separators=(",",":"))
import os; print(os.path.getsize("fig_data.json"))

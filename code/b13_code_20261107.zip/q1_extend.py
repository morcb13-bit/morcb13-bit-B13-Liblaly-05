import math, itertools
from collections import Counter
import q1_match as Q
P = Q.plane_points(Q.h_fig)
c = sum(Q.zf(p) for p in P) / len(P)
sub = [p for p in P if abs(Q.zf(p) - c) <= 30]
rest = [p for p in P if abs(Q.zf(p) - c) > 30]
Q.prepare(sub)
dP = min(Q.n2(Q.zsub(a, b)) for a, b in itertools.combinations(sub, 2))
p0, p1 = next((a, b) for a, b in itertools.permutations(sub, 2) if abs(Q.n2(Q.zsub(a, b)) - dP) < 1e-9)
s0 = sum(Q.zf(q) for q in Q.S) / len(Q.S)
best = Counter(); worst_rad = []
for refl in (False, True):
    PP = [Q.conj(x) for x in sub] if refl else sub
    RR = [Q.conj(x) for x in rest] if refl else rest
    a0, a1 = (Q.conj(p0), Q.conj(p1)) if refl else (p0, p1)
    e = Q.zsub(a1, a0); N = Q.zmul(e, Q.conj(e))
    for q0, q1 in Q.adjS:
        k = Q.zmul(Q.zsub(q1, q0), Q.conj(e))
        if all(Q.zadd(Q.zmul(Q.zsub(p, a0), k), Q.zmul(N, q0)) in Q.NS[N] for p in PP):
            ins = 0; miss_r = []
            for p in RR:
                R = Q.zadd(Q.zmul(Q.zsub(p, a0), k), Q.zmul(N, q0))
                if R in Q.NS[N]: ins += 1
                else: miss_r.append(abs(Q.zf(R) / Q.zf(N) - s0))
            best[ins] += 1
            if ins == max(best): worst_rad = miss_r
print("119 個が入る写し方で、外側の %d 個のうち入る数の分布:" % len(rest), dict(sorted(best.items())))
print("いちばん多く入る写し方で、入らない点の像の、平面のペンローズの中心からの距離:", sorted(round(r, 1) for r in worst_rad))
# 平面のペンローズ側の、その距離での五角形の密度（完全に埋まっているか）
for R0 in (20, 40, 60, 80, 100):
    ring = [q for q in Q.S if R0 - 5 <= abs(Q.zf(q) - s0) < R0 + 5]
    print("   平面のペンローズの半径 %d 前後の帯にある五角形 %d 個" % (R0, len(ring)))

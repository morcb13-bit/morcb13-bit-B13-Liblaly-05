"""オートマトンを 60 歩（5 回対称の組を 60 回）まで進め、円環の中心と五角形を書き出す。"""
import json, time
import ring_automaton as RA
t = time.time()
W = RA.start((0, 2))
n, rej = RA.grow(W, 10 ** 9, 60, log=True)
sym = all(RA.rot(c, 1) in set(W.rings) for c in W.rings)
print("60 歩：進んだ歩 %d・円環 %d・五角形 %d・5 回回転で自分に写る %s・退けた組 %d・%.0f 秒" % (n, len(W.rings), len(W.pent), sym, rej, time.time() - t))
json.dump({"rings": [list(c) for c in W.rings],
           "pents": [[list(p), 1 if vs is RA.VLO else 0, rs] for p, (vs, rs) in W.pent.items()]},
          open("ra60.json", "w"))

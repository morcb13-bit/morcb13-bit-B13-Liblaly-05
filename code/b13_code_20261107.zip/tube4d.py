"""tube4d.py ── 第13章：30面体の管の 4 次元版。600胞体の大円の十角形のまわりに、五角形 5 個ずつ 10 段の管が閉じるか。
600胞体の頂点 120 個は cell600_string.py と同じ（a＋bφ の整数、半径 2）。判定はすべて整数。"""
import itertools
from collections import Counter
from zphi import Z
import cell600_string as C
V, adj, dot = C.V, C.adj, C.dot
P = Z(0, 1)
idx = {v: i for i, v in enumerate(V)}
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def mul(k, a): return tuple(k * x for x in a)
# ---- 大円の十角形：隣り合う 2 頂点から v(k+1) ＝ φ·v(k) − v(k−1)
v0 = V[0]; v1 = V[min(adj[0])]
D = [v0, v1]
while True:
    nxt = sub(mul(P, D[-1]), D[-2])
    if nxt == v0: break
    D.append(nxt); assert nxt in idx and len(D) <= 20
print("大円の十角形：頂点 %d（すべて600胞体の頂点 %s）" % (len(D), all(d in idx for d in D)))
Dp = [v for v in V if all(dot(v, d) == Z() for d in D)]
print("十角形のどの頂点とも直交する頂点:", len(Dp))
rest = [v for v in V if v not in set(D) and v not in set(Dp)]
# D の面への近さ：D の頂点との内積の二乗の和 と D′ の頂点との内積の二乗の和を比べる
def w(v, S): return sum((dot(v, s) * dot(v, s) for s in S), Z())
near = [v for v in rest if (w(v, D) - w(v, Dp)).sign() > 0]
far = [v for v in rest if (w(v, D) - w(v, Dp)).sign() < 0]
tie = len(rest) - len(near) - len(far)
print("K1 残り %d：D に近い %d・D′ に近い %d・どちらとも言えない %d" % (len(rest), len(near), len(far), tie))
# 段：D のどの頂点との内積が一番大きいか（同点なら段を決められない）
layers = {}
amb = 0
for v in near:
    vals = [dot(v, d) for d in D]
    best = [k for k in range(10) if all((vals[k] - vals[j]).sign() >= 0 for j in range(10))]
    # 段は十角形の頂点の真ん中（隣り合う 2 頂点と同じ内積）に来る。その組 (k, k+1) の k を段の番号にする
    if len(best) == 2 and (best[1] - best[0]) % 10 in (1, 9):
        k = best[0] if (best[1] - best[0]) % 10 == 1 else best[1]
        layers.setdefault(k, []).append(v)
    elif len(best) == 1:
        layers.setdefault(("頂点の上", best[0]), []).append(v)
    else:
        amb += 1
print("   十角形の辺の真ん中に来る段の頂点の数:", [len(layers.get(k, [])) for k in range(10)], "／段を決められない頂点", amb)
def regular_pentagon(pts):
    if len(pts) != 5: return False
    d = Counter(dot(sub(a, b), sub(a, b)) for a, b in itertools.combinations(pts, 2))
    if len(d) != 2 or sorted(d.values()) != [5, 5]: return False
    a, b = sorted(d, key=lambda z: z.a + 1.618 * z.b)
    return b == a * P * P
okp = all(regular_pentagon(layers.get(k, [])) for k in range(10))
print("   どの段も正五角形:", okp)
# K2 隣の段とのつながり
deg = Counter()
for k in range(10):
    for v in layers.get(k, []):
        up = sum(1 for u in layers.get((k + 1) % 10, []) if idx[u] in adj[idx[v]])
        dn = sum(1 for u in layers.get((k - 1) % 10, []) if idx[u] in adj[idx[v]])
        same = sum(1 for u in layers.get(k, []) if idx[u] in adj[idx[v]])
        deg[(dn, same, up)] += 1
print("K2 （下の段, 同じ段, 上の段）との辺の数 → 頂点数:", dict(deg))
ok2 = set(deg) == {(2, 2, 2)}
print("   10 段目の次が 1 段目に戻って閉じる（どの段も上下に 2 本ずつ）:", ok2)
# D′ のまわりも同じか
print("   D′ のまわりの 50 個も同じ数:", len(far) == 50)
# 負の対照：頂点 1 つのまわりの正二十面体から、軸の両端を除いたジグザグの 10 個
nb = sorted(adj[0])
ico = [V[i] for i in nb]
pole = ico[0]; anti = max(ico, key=lambda u: (-(dot(u, pole))).a + 1.618 * (-(dot(u, pole))).b)
zig = [u for u in ico if u not in (pole, anti)]
ortho = [v for v in V if all(dot(v, z) == Z() for z in zig)]
print("対照 正二十面体のジグザグ 10 個（大円ではない）：どれとも直交する頂点", len(ortho), "（10 でなければ、管の分け方は成り立たない）")

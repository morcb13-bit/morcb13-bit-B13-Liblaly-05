"""芯を通る30面体と、芯の上の中空の区間を書き出す（小数にするのは図のためだけ）。"""
import json
from zphi import *
from ring5x10 import A
import export_fig as E
import core_hollow as C
H=json.load(open("helix5x10.json"))
pick=lambda kk:[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
fz=lambda z:E.f(z)
def one(k,Q,turns=3):
    h=C.screw(k,tuple(Q)); U=C.U
    us=[list(U)]
    for _ in range(5*turns-1): us.append([h(x) for x in us[-1]])
    owner={}
    for i,un in enumerate(us):
        for x in un: owner.setdefault(x,[]).append(i)
    allc=sorted(owner)
    o=[U[0]]
    for _ in range(4): o.append(h(o[-1]))
    P0=tuple(sum(x[t] for x in o) for t in range(6))
    P={c:E.frame(E.fv(phys(c))) for c in allc}
    ax=E.frame(E.fv(phys(P0))); ax=[v/5 for v in ax]
    Af=E.frame(E.fv(A))
    zs=[P[c][2] for c in allc]; cz=(max(zs)+min(zs))/2
    rts=[]; segs=[]
    for c in allc:
        iv=C.interval(P0,tuple(5*c[t] for t in range(6)),5)
        core=iv is not None
        if core:
            lo=E.f(iv[0].a)/E.f(iv[0].b); hi=E.f(iv[1].a)/E.f(iv[1].b)
            z0=ax[2]+lo*Af[2]/5-cz; z1=ax[2]+hi*Af[2]/5-cz
            segs.append(sorted([round(z0,4),round(z1,4)]))
        rts.append({"p":[round(P[c][0]-ax[0],4),round(P[c][1]-ax[1],4),round(P[c][2]-cz,4)],
                    "u":owner[c][0],"c":core})
    segs.sort()
    gaps=[[segs[i][1],segs[i+1][0]] for i in range(len(segs)-1) if segs[i+1][0]-segs[i][1]>1e-6]
    return {"rts":rts,"segs":segs,"gaps":gaps,"ncore":sum(r["c"] for r in rts),"n":len(rts)}
D={"faces":E.D["faces"],"t1":one(1,pick(1)["Q"]),"t2":one(2,pick(2)["Q"])}
for k in ("t1","t2"): print(k,D[k]["n"],D[k]["ncore"],"すき間",len(D[k]["gaps"]),"例",D[k]["gaps"][:2],D[k]["segs"][:2])
json.dump(D,open("core_data.json","w"),separators=(",",":"))

#  k1_inner_cube.py  検定K1：n 次元立方体の頂点を結んで、面に乗らない正k次元立方体が中にできるか（2026-10-10 の作り直し）
#      頂点は ±1 の列。一つの頂点から直交し長さの等しい k 本の向きをとり、2^k 点がすべて頂点なら正k次元立方体。
#      辺の長さ² 4 は面に乗るもの、4 より大きければ中にできるもの。すべて整数。
#      期待値：中の正k次元立方体は 2k 次元で初めて現れる。中の正方形は n＝4,5,6,7 で 12・120・880・5600
#      対照：面に乗るものの個数は C(n,k)·2^(n−k) と一致すること
from itertools import product
from math import comb
def cubes(n, k):
    V = [tuple(v) for v in product((1, -1), repeat=n)]
    S = set(V); v0 = (1,) * n
    D = [tuple(w[i] - v0[i] for i in range(n)) for w in V if w != v0]
    found = {}
    def grow(ch, st):
        if len(ch) == k:
            pts = []
            for m in range(1 << k):
                p = list(v0)
                for j in range(k):
                    if m >> j & 1: p = [p[i] + ch[j][i] for i in range(n)]
                pts.append(tuple(p))
            if all(p in S for p in pts):
                L = sum(x * x for x in ch[0])
                found.setdefault(L, set()).add(frozenset(pts))
            return
        for i in range(st, len(D)):
            a = D[i]
            if ch and sum(x*x for x in a) != sum(x*x for x in ch[0]): continue
            if all(sum(x*y for x, y in zip(a, c)) == 0 for c in ch): grow(ch + [a], i + 1)
    grow([], 0)
    return {L: len(s) * (1 << n) // (1 << k) for L, s in found.items()}
ok = True
first = {}
for k in (1, 2, 3):
    for n in range(k, 8):
        c = cubes(n, k)
        face = c.get(4, 0); inner = sum(v for L, v in c.items() if L > 4)
        if face != comb(n, k) * 2 ** (n - k): ok = False
        if inner and k not in first: first[k] = n
        if k == 2: print("n=%d 正方形：面 %d・中 %d" % (n, face, inner))
print("中の正k次元立方体が初めて現れる次元", first)
sq = [sum(v for L, v in cubes(n, 2).items() if L > 4) for n in (4, 5, 6, 7)]
ok = ok and first == {1: 2, 2: 4, 3: 6} and sq == [12, 120, 880, 5600]
print("中の正方形 n=4..7", sq, "／面の個数は C(n,k)·2^(n−k) と一致")
print("総合", "OK" if ok else "NG")

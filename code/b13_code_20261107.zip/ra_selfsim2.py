import json
import q1_match as Q
import ring_automaton as RA
import ra_selfsim as S
PHI = (1, 0, 1, -1)
pw = [(1, 0, 0, 0)]
for k in range(6): pw.append(Q.zmul(pw[-1], PHI))
R = max(abs(Q.zf(c)) for c in S.C) / 50
print("60 歩の範囲：いちばん外の円環の半径 %.1f" % R)
for steps in range(0, 6):
    W = RA.start((0, 2)); RA.grow(W, 10 ** 9, steps, log=False); tm = list(W.rings)
    rt = max(abs(Q.zf(c)) for c in tm) / 50
    row = []
    for k in range(1, 6):
        if rt * 1.618034 ** k + 1 > R: row.append("範囲外"); continue
        h = S.find(tm, pw[k]); row.append(str(len(h)))
    print("出発から %d 歩の形（円環 %d 個・半径 %.1f）：φ^1〜φ^5 倍で見つかった数 %s" % (steps, len(tm), rt, " / ".join(row)))

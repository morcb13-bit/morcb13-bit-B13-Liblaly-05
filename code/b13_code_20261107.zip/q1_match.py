"""Q1：切り口の正五角形の中心の集まりが、平面のペンローズ（P1）の五角形の中心の集まりに、そのまま含まれるか。
平面のペンローズはリポジトリの carrier_1245.json（円環 1245 個、五角形の中心を Z[ζ10] の整数4つで持つ）。
切り口の点も Z[ζ10] の整数4つに直し、相似（回転・鏡映・平行移動・大きさ）で重ねて、等号だけで判定する。"""
import json, math, itertools, sys
from zphi import Z, GEN, dot
import cut_tiling as T
# ---- Z[ζ10]：ζ = e^{iπ/5}、基底 1,ζ,ζ²,ζ³、ζ⁴ = −1+ζ−ζ²+ζ³
def zmul(a, b):
    p = [0] * 7
    for i in range(4):
        for j in range(4): p[i + j] += a[i] * b[j]
    for k in (6, 5, 4):                     # ζ^k = ζ^(k-4)·(−1+ζ−ζ²+ζ³)
        c = p[k]; p[k] = 0
        if c:
            p[k - 4] -= c; p[k - 3] += c; p[k - 2] -= c; p[k - 1] += c
    return tuple(p[:4])
def zadd(a, b): return tuple(x + y for x, y in zip(a, b))
def zsub(a, b): return tuple(x - y for x, y in zip(a, b))
ZETA = (0, 1, 0, 0)
def zpow(j):
    r = (1, 0, 0, 0)
    for _ in range(j % 10): r = zmul(r, ZETA)
    return r
def conj(a):                                # ζ → ζ⁻¹ ＝ −ζ⁴
    r = (0, 0, 0, 0); zi = zpow(9)
    pw = (1, 0, 0, 0)
    for k in range(4):
        r = zadd(r, tuple(a[k] * x for x in pw)); pw = zmul(pw, zi)
    return r
def zf(a):
    c = complex(math.cos(math.pi / 5), math.sin(math.pi / 5))
    return sum(a[k] * c ** k for k in range(4))
# ---- 切り口の点を Z[ζ10] に：軸 A に垂直な面へ落とした生成子 5 本は、正五角形の向き（36° の倍数）に並ぶ
PH = (1 + 5 ** .5) / 2
f = lambda z: z.a + z.b * PH
A = GEN[2]; Af = [f(x) for x in A]; nA = math.sqrt(sum(x * x for x in Af)); w = [x / nA for x in Af]
p0 = [f(x) for x in GEN[0]]; dd = sum(p0[i] * w[i] for i in range(3)); u = [p0[i] - dd * w[i] for i in range(3)]
nu = math.sqrt(sum(x * x for x in u)); u = [x / nu for x in u]
v = [w[1] * u[2] - w[2] * u[1], w[2] * u[0] - w[0] * u[2], w[0] * u[1] - w[1] * u[0]]
J = {}
for k in range(6):
    if k == 2: continue
    g = [f(x) for x in GEN[k]]; gp = [sum(g[i] * u[i] for i in range(3)), sum(g[i] * v[i] for i in range(3))]
    ang = math.degrees(math.atan2(gp[1], gp[0])) % 360
    j = round(ang / 36)
    assert abs(ang - 36 * j) < 1e-9, ang
    J[k] = j % 10
print("面に落とした生成子の向き（36° の何倍か）:", J)
def cutz(n):           # 30面体の中心 ×2 ＝ 2n ＋ (1,…,1) の影
    c2 = [2 * x + 1 for x in n]
    r = (0, 0, 0, 0)
    for k, j in J.items(): r = zadd(r, tuple(c2[k] * x for x in zpow(j)))
    return r
def plane_points(h): return [cutz(n) for n, side in T.planes[h]]
# 写し方の確かめ（小数で）：切り口の図の座標と比べる
h_fig = max(T.planes, key=lambda h: len(T.planes[h]))
# ---- 平面のペンローズ
S = [tuple(int(x) for x in k.split(",")) for k in json.load(open(__import__("os").path.join(__import__("os").path.dirname(__import__("os").path.abspath(__file__)), "carrier_1245.json")))["cells"]]
Sset = set(S)
print("平面のペンローズの五角形", len(S))
# 隣り合う五角形（中心の距離が最小）の組
def n2(a): z = zf(a); return z.real ** 2 + z.imag ** 2
dmin = min(n2(zsub(a, b)) for a, b in itertools.combinations(S[:300], 2))
adjS = [(a, b) for a in S for b in S if a != b and abs(n2(zsub(a, b)) - dmin) < 1e-9]
print("平面のペンローズの隣り合う五角形の組", len(adjS))
PHI = (1, 0, 1, -1)                     # φ ＝ 1＋ζ²−ζ³
def match(P):
    """P（切り口の点）が S に相似で含まれるか。見つかった写し方の数を返す（途中で 1 つ見つかれば止めない）"""
    # P の中の隣り合う組を 1 つ選ぶ
    dP = min(n2(zsub(a, b)) for a, b in itertools.combinations(P, 2))
    p0, p1 = next((a, b) for a, b in itertools.permutations(P, 2) if abs(n2(zsub(a, b)) - dP) < 1e-9)
    hits = 0
    for refl in (False, True):
        PP = [conj(x) for x in P] if refl else P
        a0, a1 = (conj(p0), conj(p1)) if refl else (p0, p1)
        e = zsub(a1, a0); ec = conj(e); N = zmul(e, ec)          # |e|²（実数、Z[ζ10] の元）
        for q0, q1 in adjS:
            fq = zsub(q1, q0)
            k = zmul(fq, ec)                                       # 写し方 ×N
            ok = True
            for p in PP:
                R = zadd(zmul(zsub(p, a0), k), zmul(N, q0))       # N·Q
                # N·Q が N·S に入るか：N を掛けた S の集合と比べる
                if R not in NS[N]: ok = False; break
            if ok: hits += 1
    return hits
NS = {}
def prepare(P):
    dP = min(n2(zsub(a, b)) for a, b in itertools.combinations(P, 2))
    p0, p1 = next((a, b) for a, b in itertools.permutations(P, 2) if abs(n2(zsub(a, b)) - dP) < 1e-9)
    for refl in (False, True):
        a0, a1 = (conj(p0), conj(p1)) if refl else (p0, p1)
        e = zsub(a1, a0); N = zmul(e, conj(e))
        if N not in NS: NS[N] = {zmul(N, q) for q in S}
if __name__ == "__main__":
    P = plane_points(h_fig)
    # 平面のペンローズの範囲に収まるよう、切り口の中心近くの点に絞る（半径で）
    c = (sum(zf(p) for p in P) / len(P))
    for rmax in (6, 10, 14):
        Q = [p for p in P if abs(zf(p) - c) <= rmax * math.sqrt(dmin) * 0 + rmax * (abs(zf(P[0]) - zf(P[1])) if False else 1) * 0 + abs(zf(p) - c) * 0 + rmax * 3.0]
        Q = Q if len(Q) >= 5 else P
        prepare(Q)
        print("切り口の中心から %2d 以内の五角形 %3d 個 → 平面のペンローズに相似で含まれる写し方 %d" % (rmax * 3, len(Q), match(Q)))

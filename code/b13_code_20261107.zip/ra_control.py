import ring_automaton as RA
for check in (True, False):
    W = RA.start((0, 2))
    n, rej = RA.grow(W, 20 * 50, 400, check=check, log=False)
    print("重なりの判定 %s：止まった段 %d・円環 %d・五角形 %d" % ("あり" if check else "なし（対照）", n, len(W.rings), len(W.pent)))

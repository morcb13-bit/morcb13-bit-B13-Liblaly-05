import json
import q1_match as Q
import ring_automaton as RA
import ra_selfsim as S
D = json.load(open("ra60.json"))
rings = [tuple(c) for c in D["rings"]]
step_of = [0] * 10 + [1 + (i - 10) // 5 for i in range(10, len(rings))]
h = S.find(S.t10, (2, 0, 1, -1))
big = sorted(next(iter(h)))
f = lambda z: [round(Q.zf(z).real / 50, 4), round(Q.zf(z).imag / 50, 4)]
pents = []
for p, lo, rs in D["pents"]:
    vs = RA.VLO if lo else RA.VHI
    q = RA.ordered([Q.zf(Q.zadd(tuple(p), v)) / 50 for v in vs])
    pents.append({"q": [[round(z.real, 4), round(z.imag, 4)] for z in q], "s": min(step_of[r] for r in rs), "sh": len(rs) > 1})
out = {"pents": pents, "rings": [f(c) for c in rings], "step": step_of, "big": [f(c) for c in big],
       "start": [f(c) for c in S.t10], "nsteps": max(step_of)}
json.dump(out, open("ra_fig.json", "w"), separators=(",", ":"))
import os; print(len(pents), "五角形", os.path.getsize("ra_fig.json") // 1024, "KB")

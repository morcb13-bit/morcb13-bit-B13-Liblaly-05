"""cut_plane.py ── 30面体・輪を 5 回軸に垂直な面で切る（S0）。整数だけ。
高さは x·A（A ＝ GEN[2]）。座標はすべて 2 倍で持つ：30面体の中心 2c、頂点 2c ＋ Σ s_k G_k。
30面体の本当の頂点（64 通りの符号のうち 32 個）は、符号の並びが s_k ＝ sign(G_k·w) となる向き w があるもの。
w の候補は、6 枚の面 G_k·w ＝ 0 が球を分ける区画の中の点（区画の頂点 ±G_i×G_j を 3 つ足したもの）。"""
import json, itertools
from collections import Counter
from zphi import Z, GEN, dot, cross
import ring5x10 as R
U = R.U
A = GEN[2]; P = Z(0, 1)
def phys(v): return tuple(sum((GEN[k][t] * v[k] for k in range(6)), Z()) for t in range(3))
rays = []
for i, j in itertools.combinations(range(6), 2):
    c = cross(GEN[i], GEN[j]); rays += [c, tuple(-x for x in c)]
VS = set()
for a, b, c in itertools.combinations(rays, 3):
    w = tuple(a[t] + b[t] + c[t] for t in range(3))
    s = tuple(dot(G, w).sign() for G in GEN)
    if 0 not in s: VS.add(s)
VS = sorted(VS)
EDGES = [(s, t) for s, t in itertools.combinations(VS, 2) if sum(1 for a, b in zip(s, t) if a != b) == 1]
OFF = {s: tuple(sum((GEN[k][t] * s[k] for k in range(6)), Z()) for t in range(3)) for s in VS}
def section(c2, h2):
    hv = {s: (dot(tuple(c2[t] + OFF[s][t] for t in range(3)), A) - h2).sign() for s in VS}
    on = [tuple(c2[t] + OFF[s][t] for t in range(3)) for s in VS if hv[s] == 0]
    crossing = sum(1 for s, t in EDGES if hv[s] * hv[t] < 0)
    return on, crossing
def regular_pentagon(pts):
    if len(pts) != 5: return False
    d = Counter(dot(tuple(p[t] - q[t] for t in range(3)), tuple(p[t] - q[t] for t in range(3))) for p, q in itertools.combinations(pts, 2))
    if len(d) != 2 or sorted(d.values()) != [5, 5]: return False
    a, b = sorted(d, key=lambda z: z.a + 1.618 * z.b)
    return b == a * P * P                     # 対角² ＝ φ² × 辺²
if __name__ == "__main__":
    print("30面体の頂点 %d・辺 %d（期待 32・60）" % (len(VS), len(EDGES)))
    L2 = (Z(1) + P * 2) * 2
    c2 = phys(tuple(2 * x for x in U[0])); H2 = dot(c2, A)
    on, cr = section(c2, H2 - L2)
    print("S0 中心から 1＋2φ 下で切る：面の上の頂点 %d・面をまたぐ辺 %d・正五角形 %s" % (len(on), cr, regular_pentagon(on)))
    on, cr = section(c2, H2 + L2)
    print("   中心から 1＋2φ 上で切る：面の上の頂点 %d・面をまたぐ辺 %d・正五角形 %s" % (len(on), cr, regular_pentagon(on)))
    on, cr = section(c2, H2 - L2 + Z(1))
    print("   対照 少しずらした面：面の上の頂点 %d・面をまたぐ辺 %d・正五角形 %s" % (len(on), cr, regular_pentagon(on)))
    hs = sorted({dot(phys(tuple(2 * x for x in u)), A) for u in U}, key=lambda z: z.a + 1.618 * z.b)
    mid = hs[0] + L2
    print("   輪の上の段と下の段の高さの差 ＝ 2×(1＋2φ):", hs[1] - hs[0] == L2 * 2)
    res = [section(phys(tuple(2 * x for x in u)), mid) for u in U]
    ok = all(cr == 0 and regular_pentagon(on) for on, cr in res)
    print("S0 10 個の輪を真ん中の面で切る：10 個とも正五角形", "OK" if ok else "NG")
    # 五角形の中心と向き：中心は30面体の中心の影、向きは上の段・下の段で 36° 違う
    AA = dot(A, A)
    sh = lambda p: tuple(AA * p[t] - dot(p, A) * A[t] for t in range(3))
    cens = [sh(phys(tuple(2 * x for x in u))) for u in U]
    cen = tuple(sum((c[t] for c in cens), Z()) for t in range(3))
    def toward_center(on, c):
        # 五角形の頂点のうち、輪の中心に一番近いものと遠いものの距離² を比べ、頂点が中心を向くか辺が向くか
        ds = sorted([dot(tuple(10 * sh(p)[t] - cen[t] for t in range(3)), tuple(10 * sh(p)[t] - cen[t] for t in range(3))) for p in on], key=lambda z: z.a + 1.618 * z.b)
        return "頂点が中心を向く" if not (ds[0] == ds[1]) else "辺が中心を向く"
    kinds = Counter((dot(phys(tuple(2 * x for x in u)), A) == hs[0], toward_center(on, None)) for u, (on, cr) in zip(U, res))
    print("   （下の段か, 中心を向くもの）の組:", dict(kinds))

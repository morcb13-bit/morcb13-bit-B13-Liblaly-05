"""cp2_ico.py ── タイリングの中の30面体10個の輪がつくる、正二十面体の集まり（H1〜H3）。整数だけ。"""
import json, itertools
from collections import Counter
from zphi import Z, GEN, dot
import ring5x10 as R
import cp2_match as M          # 輪の出現（occ_sets）と塊の集合 B を使う
B, rings = M.B, M.rings
phys = lambda n: tuple(sum((GEN[k][t] * n[k] for k in range(6)), Z()) for t in range(3))
def d2(a, b):
    x = phys(tuple(a[t] - b[t] for t in range(6))); return dot(x, x)
# ---- 8個共有でつなぐ
idx = {r: i for i, r in enumerate(rings)}
par = list(range(len(rings)))
def f(i):
    while par[i] != i: par[i] = par[par[i]]; i = par[i]
    return i
for a, b in itertools.combinations(range(len(rings)), 2):
    if len(rings[a] & rings[b]) == 8: par[f(a)] = f(b)
groups = {}
for i in range(len(rings)): groups.setdefault(f(i), []).append(i)
clusters = []
for g in groups.values():
    pts = frozenset().union(*[rings[i] for i in g])
    clusters.append((pts, len(g)))
print("8個共有でつないだ集まり", len(clusters), "／集まりの大きさ（30面体の数, 輪の数）", dict(Counter((len(p), n) for p, n in clusters)))
def ico_check(pts):
    pts = sorted(pts)
    if len(pts) != 12: return False, None
    s = tuple(sum(p[t] for p in pts) for t in range(6))           # 12 倍した中心
    rad = {d2(tuple(12 * p[t] for t in range(6)), s) for p in pts}
    dist = Counter(d2(a, b) for a, b in itertools.combinations(pts, 2))
    counts = sorted(dist.values())
    return (len(rad) == 1 and counts == [6, 30, 30]), s
ok = [ico_check(p) for p, n in clusters]
print("H1 正二十面体（中心から等距離・距離の数 30/30/6）:", sum(1 for o, s in ok if o), "/", len(clusters),
      "／輪がちょうど6つ:", sum(1 for p, n in clusters if n == 6))
# 負の対照：輪1つ＋無関係な塊2個
r0 = sorted(rings[0]); far = [b for b in B if all(d2(b, x).a > 400 for x in r0)][:2]
print("対照 輪＋無関係な塊2個:", ico_check(set(r0) | set(far))[0])
# ---- H2 中心
centers = []
for (p, n), (o, s) in zip(clusters, ok):
    if not o: continue
    if all(x % 12 == 0 for x in s):
        c = tuple(x // 12 for x in s)
        centers.append((c, c in B))
    else:
        centers.append((None, False))
print("H2 中心が格子点:", sum(1 for c, b in centers if c is not None), "／中心にも30面体の塊:", sum(1 for c, b in centers if b))
# 中心と12個の距離（面接触の一歩の距離²と比べる）
step = d2(tuple(R.U[0]), tuple(R.U[1])) if False else None
c, _ = centers[0]
if c is not None:
    p0 = sorted(clusters[0][0])[0]
    print("   中心から12個までの距離²:", d2(c, p0), "／輪の中で面で接する一歩の距離²:",
          min(d2(a, b) for a, b in itertools.combinations(R.U, 2)))
# ---- H3 集まりどうし
icos = [(p, c) for (p, n), (c, b) in zip(clusters, centers) if c is not None]
sh = Counter(len(a & b) for (a, _), (b, _) in itertools.combinations(icos, 2))
print("H3 正二十面体どうしが共有する塊の数:", dict(sorted(sh.items())))
dc = Counter(d2(a, b) for (_, a), (_, b) in itertools.combinations(icos, 2))
near = sorted(dc.items(), key=lambda kv: kv[0].a + 1.618034 * kv[0].b)[:5]
print("   中心どうしの距離²（近い順）:", [(str(k), v) for k, v in near])
json.dump([{"pts": [list(x) for x in sorted(p)], "center": list(c)} for p, c in icos], open("cp2_ico.json", "w"))

#  simplex_dims.py  単体を面でつないだ紐を 2〜10 次元で（2026-10-06 の pair2n の作り直し）
#
#      一歩の規則 v(k+1) ＝ (2/n)(直前 n 個の和) − v(k−n) の特性多項式
#          P_n(x) ＝ n·x^(n+1) − 2(x^n ＋ … ＋ x) ＋ n
#      を整数で割り、横の動きを「回る面」と「裏返り」に分ける。
#      単位円の上の根の数え上げも、x＋1/x ＝ y と置いてスツルム列（分数）で数えるので、浮動小数は使わない。
#
#      検定（期待値は 2026-10-06 の記録）
#        D1  どの n でも (x−1)² で割り切れる（軸の方向に一定に進む部分）
#        D2  偶数の n では (x＋1) で割り切れ、奇数の n では割り切れない（裏返り）
#        D3  残りの因子の根はすべて単位円の上にあり、回る面の数は ⌊(n−1)/2⌋
#        D4  横の動きの数（回る面×2 ＋ 裏返り）は n−1
#        D5  「回る面がちょうど 1 つで裏返りがない」のは n＝3 だけ
#      対照
#        D3' 単位円の上に無い根を持つ多項式（例 x²−3x＋1）では、数え上げが 0 を返す

from fractions import Fraction as F

def poly(n):
    # 係数を低い次数から：定数 n、x..x^n は −2、x^(n+1) は n
    return [n] + [-2] * n + [n]

def divide(p, d):
    """p ÷ d（どちらも低い次数から）。割り切れれば商を、割り切れなければ None"""
    p = [F(c) for c in p]
    q = [F(0)] * (len(p) - len(d) + 1)
    for i in range(len(q) - 1, -1, -1):
        c = p[i + len(d) - 1] / d[-1]
        q[i] = c
        for j, dc in enumerate(d):
            p[i + j] -= c * dc
    return q if all(x == 0 for x in p) else None

def trim(p):
    p = list(p)
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p

def to_y(c):
    """回文の多項式 c（次数 2m）を R(y), y＝x＋1/x に。x^m R(x+1/x) ＝ c(x)"""
    m = (len(c) - 1) // 2
    assert all(c[i] == c[len(c) - 1 - i] for i in range(len(c)))
    D = [[F(2)], [F(0), F(1)]]          # D_j(y) ＝ x^j＋x^-j
    for j in range(2, m + 1):
        a = [F(0)] + D[j - 1]
        b = D[j - 2] + [F(0)] * 2
        D.append([x - y for x, y in zip(a, b + [F(0)] * (len(a) - len(b)))])
    R = [F(0)] * (m + 1)
    R[0] += c[m]
    for j in range(1, m + 1):
        for k, v in enumerate(D[j]):
            R[k] += c[m + j] * v
    return trim(R)

def ev(p, x):
    s = F(0)
    for c in reversed(p):
        s = s * x + c
    return s

def deriv(p):
    return trim([k * p[k] for k in range(1, len(p))]) or [F(0)]

def prem(a, b):
    a = [F(x) for x in a]
    while len(a) >= len(b) and any(a):
        c = a[-1] / b[-1]
        sh = len(a) - len(b)
        for j, bc in enumerate(b):
            a[sh + j] -= c * bc
        a = trim(a)
        if len(a) < len(b):
            break
    return a

def sturm_count(p, lo, hi):
    """(lo, hi) の中の実根の数（重複は 1 つと数える）"""
    seq = [trim(p), deriv(p)]
    while len(seq[-1]) > 1 or seq[-1][0] != 0:
        r = prem(seq[-2], seq[-1])
        r = [-x for x in r]
        if not any(r):
            break
        seq.append(trim(r))
        if len(seq[-1]) == 1:
            break
    def changes(x):
        vals = [ev(s, x) for s in seq]
        vals = [v for v in vals if v != 0]
        return sum(1 for a, b in zip(vals, vals[1:]) if (a > 0) != (b > 0))
    return changes(lo) - changes(hi)

def rotating_planes(c):
    """回文の多項式 c の根のうち、単位円の上（実でない）にある組の数"""
    if len(c) == 1:
        return 0, True
    R = to_y(c)
    m = len(R) - 1
    inside = sturm_count(R, F(-2), F(2))
    edge = ev(R, F(2)) == 0 or ev(R, F(-2)) == 0
    return inside, (inside == m and not edge)

def main():
    rows = []
    ok = {"D1": True, "D2": True, "D3": True, "D4": True}
    for n in range(2, 11):
        p = poly(n)
        q = divide(p, [1, -2, 1])                  # (x−1)²
        if q is None:
            ok["D1"] = False
            continue
        q = trim(q)
        q2 = divide(q, [1, 1])                     # (x＋1)
        flip = q2 is not None
        if flip:
            q = trim(q2)
        if flip != (n % 2 == 0):
            ok["D2"] = False
        planes, all_on = rotating_planes(q)
        if planes != (n - 1) // 2 or not all_on:
            ok["D3"] = False
        moves = 2 * planes + (1 if flip else 0)
        if moves != n - 1:
            ok["D4"] = False
        rows.append((n, planes, flip, moves, [int(c) if c.denominator == 1 else c for c in q]))
    print(" n  回る面  裏返り  横の動き  残りの因子（低い次数から）")
    for n, pl, fl, mv, q in rows:
        print("%2d  %4d    %-5s  %5d     %s" % (n, pl, "あり" if fl else "なし", mv, q))
    one = [n for n, pl, fl, mv, q in rows if pl == 1 and not fl]
    ok["D5"] = one == [3]
    print("回る面 1 つ・裏返りなし の n:", one)
    # 対照：x²−3x＋1（根は φ² と 1/φ²、単位円の上ではない）
    pl, allon = rotating_planes([1, -3, 1])
    print("対照 D3' x²−3x＋1 の単位円上の組:", pl, "（0 なら数え上げは NG を返せる）")
    print("\n総合", "OK" if all(ok.values()) and pl == 0 else "NG", ok)

if __name__ == "__main__":
    main()

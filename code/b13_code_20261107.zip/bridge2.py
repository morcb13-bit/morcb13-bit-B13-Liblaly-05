"""B2・B3：つなぎの円環を 5 つ（5 回対称にそろえて）足した全体が P1 に含まれるか／切り口の灰色の五角形と一致するか。"""
import itertools, math
from collections import Counter, defaultdict
import q1_match as Q
import bridge as Bm
cen10, col10, colored, bridges = Bm.cen10, Bm.col10, Bm.colored, Bm.bridges
g10 = (sum(c[0] for c in cen10), sum(c[1] for c in cen10), sum(c[2] for c in cen10), sum(c[3] for c in cen10))  # 組の中心 ×50
ang = lambda c: math.atan2(Q.zf(c).imag * 5 - Q.zf(g10).imag / 10 * 1, Q.zf(c).real * 5 - Q.zf(g10).real / 10)
gc = Q.zf(g10) / 50
order = sorted(range(5), key=lambda i: math.atan2((Q.zf(cen10[i]) / 10 - gc).imag, (Q.zf(cen10[i]) / 10 - gc).real))
nxt = {order[k]: order[(k + 1) % 5] for k in range(5)}
classes = defaultdict(list)
for i, j, c, ki, kj in bridges:
    a, b, ka, kb = (i, j, ki, kj) if nxt[i] == j else (j, i, kj, ki)
    r = round(abs(Q.zf(c) / 10 - gc), 4)
    classes[(ka, kb, r)].append((a, b, c))
def div10(p):
    assert all(x % 10 == 0 for x in p); return tuple(x // 10 for x in p)
plane10 = Bm.allp10
for key, bs in sorted(classes.items()):
    if len(bs) != 5: continue
    new = set()
    for a, b, c in bs: new |= set(Bm.ring_at(c))
    allpts = colored | new
    clash = Bm.overlap(list(new - colored), list(colored)) or any(
        Bm.overlap([p for p in Bm.ring_at(c1) if p not in colored], [p for p in Bm.ring_at(c2) if p not in colored])
        for (_, _, c1), (_, _, c2) in itertools.combinations(bs, 2))
    pts = [div10(p) for p in allpts]
    Q.prepare(pts); m = Q.match(pts)
    inplane = sum(1 for p in new - colored if p in plane10)
    print("つなぎ（A 側 %d 枚おき・B 側 %d 枚おき・中心から %.3f）：五角形 計 %d 枚・食い込み %s・P1 に含まれる写し方 %d・切り口の灰色と一致 %d/%d"
          % (key[0], key[1], key[2], len(allpts), "あり" if clash else "なし", m, inplane, len(new - colored)))
# 負の対照：一致した型のつなぎの円環を 1 歩ずらす
best = [bs for key, bs in classes.items() if len(bs) == 5]

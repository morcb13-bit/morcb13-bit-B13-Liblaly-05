import json, math, itertools
import export_fig as E
D = json.load(open("cut_data.json")); PH = D["phi"]; rc = D["rc"]
# 切り口の組を 1/φ 倍に寄せた五角形の中心
cut = []
for p in D["pents"]:
    if p["r"] < 0: continue
    c = rc[p["r"]]; cx = sum(x for x, y in p["q"]) / 5; cy = sum(y for x, y in p["q"]) / 5
    cut.append((cx - (1 - 1 / PH) * c[0], cy - (1 - 1 / PH) * c[1]))
# 平面の第一層（F の影）の五角形の中心。組の中心を原点に
F = E.D["flat"]["rts"]
pts = [(r["p"][0], r["p"][1]) for r in F]
units = {}
for r in F:
    for u in r["o"]: units.setdefault(u, []).append((r["p"][0], r["p"][1]))
rcF = [(sum(x for x, y in v) / 10, sum(y for x, y in v) / 10) for v in units.values()]
g = (sum(x for x, y in rcF) / 5, sum(y for x, y in rcF) / 5)
pts = [(x - g[0], y - g[1]) for x, y in pts]
def norm_set(S):
    return sorted(set((round(x, 3), round(y, 3)) for x, y in S))
a = norm_set(cut); b = norm_set(pts)
# 尺度をそろえる（輪の半径で）
ra = max(math.hypot(x, y) for x, y in a); rb = max(math.hypot(x, y) for x, y in b)
print("切り口を寄せた五角形の中心", len(a), "／第一層の影の五角形の中心", len(b))
best = None
for k in range(40):
    th = math.radians(9 * k)
    bb = norm_set([(ra / rb * (x * math.cos(th) - y * math.sin(th)), ra / rb * (x * math.sin(th) + y * math.cos(th))) for x, y in b])
    m = len(set(a) & set(bb))
    if best is None or m > best[0]: best = (m, 9 * k)
print("回して重ねたとき一致する中心の数（最大）", best)
# 第一層の影そのものの 2 次元での食い込み（中心どうしの距離が内接直径より短い組）
side = None
cs = b
dmin = sorted(math.dist(p, q) for p, q in itertools.combinations(cs, 2))[:12]
print("第一層の影の、五角形の中心どうしの近い距離", [round(d, 3) for d in dmin])

"""cp2_match.py ── T2：タイリングの30面体の塊の中に、10個の輪・紐が同じ6次元の差で現れるか。
格子の回転・鏡映（生成子の星を保つ符号つき置換、120個）も含めて探す。整数だけ。"""
import json, itertools
from zphi import Z, GEN, dot
import core_hollow as C
import ring5x10 as R
U = R.U
d = json.load(open("cp2_tiling.json"))
B = set(tuple(n) for n in d["rts"])
print("30面体の塊", len(B))
G = [[dot(GEN[i], GEN[j]) for j in range(6)] for i in range(6)]
SYM = []
for p in itertools.permutations(range(6)):
    for sg in itertools.product((1, -1), repeat=6):
        if all(G[p[i]][p[j]] * (sg[i] * sg[j]) == G[i][j] for i in range(6) for j in range(6)):
            SYM.append((p, sg))
print("格子の対称（符号つき置換）", len(SYM))
def app(S, v):
    p, sg = S; out = [0] * 6
    for k in range(6): out[p[k]] = sg[k] * v[k]
    return tuple(out)
def occurrences(pat):
    pat = sorted(set(pat)); c0 = pat[0]
    diffs = [tuple(c[t] - c0[t] for t in range(6)) for c in pat]
    found = set()
    for S in SYM:
        sd = [app(S, v) for v in diffs]
        for n0 in B:
            if all(tuple(n0[t] + v[t] for t in range(6)) in B for v in sd):
                found.add(frozenset(tuple(n0[t] + v[t] for t in range(6)) for v in sd))
    return len(found)
H = json.load(open("helix5x10.json"))
F = [o for o in json.load(open("ring5x10_cands.json")) if o["n"] == 40 and o["ov"] == 10][0]
def chain(k, Q, nu):
    h = C.screw(k, tuple(Q)); us = [list(U)]
    for _ in range(nu - 1): us.append([h(x) for x in us[-1]])
    return sorted(set(x for u in us for x in u))
pick = lambda kk: [o for o in H if o["share"] == 2 and o["ov"] == 0 and o["k"] == kk and (o["pitch"][0] + o["pitch"][1]) > 0][0]
print("30面体 1 個（参考）:", occurrences([U[0]]))
print("30面体 2 個の面接触（輪の隣どうし）:", occurrences(U[:2]))
print("10 個の輪:", occurrences(U))
for kk in (1, 2):
    for nu in (2, 3, 5):
        print("紐 %d°・輪 %d 個（30面体 %d）:" % (72 * kk, nu, len(chain(kk, pick(kk)["Q"], nu))), occurrences(chain(kk, pick(kk)["Q"], nu)))
print("対照 平面のまま閉じた40個（食い込みあり）:", occurrences([tuple(c) for c in F["centers6"]]))
# 見つかった 10 個の輪どうしの関係（共有する30面体の数、軸の向き）
def occ_sets(pat):
    pat = sorted(set(pat)); c0 = pat[0]
    diffs = [tuple(c[t] - c0[t] for t in range(6)) for c in pat]
    found = set()
    for S in SYM:
        sd = [app(S, v) for v in diffs]
        for n0 in B:
            s = [tuple(n0[t] + v[t] for t in range(6)) for v in sd]
            if all(x in B for x in s): found.add(frozenset(s))
    return list(found)
rings = occ_sets(U)
from collections import Counter
sh = Counter(len(a & b) for a, b in itertools.combinations(rings, 2))
print("見つかった輪", len(rings), "／輪どうしが共有する30面体の数の分布", dict(sorted(sh.items())))
used = Counter(x for r in rings for x in r)
print("30面体の塊のうち輪に入るもの", len(used), "／一つの塊がいくつの輪に入るか", dict(Counter(used.values())))

"""S1：タイリングを 5 回軸に垂直な面で切り、切り口が正五角形になる30面体の塊と、同じ面に乗る輪の並びを数える。"""
import itertools
from collections import Counter, defaultdict
from zphi import Z, GEN, dot
import cut_plane as CP
import cp3_shadow as C3
A = GEN[2]; AA = dot(A, A); P = Z(0, 1)
L2 = (Z(1) + P * 2) * 2
B = C3.B
def c2of(n): return CP.phys(tuple(2 * x + 1 for x in n))           # 30面体の中心（2倍）＝ 2·基点 ＋ (1,…,1)
planes = defaultdict(list)
for n in B:
    h = dot(c2of(n), A)
    planes[h - L2].append((n, "上の段"))      # この塊の下側の五角形の面
    planes[h + L2].append((n, "下の段"))      # この塊の上側の五角形の面
sizes = Counter(len(v) for v in planes.values())
print("S1 面の数 %d／一枚の面に乗る正五角形の数の分布（多い順に5つ）:" % len(planes), sorted(sizes.items(), key=lambda kv: -kv[0])[:5])
# 同じ面の正五角形どうしは重ならない（30面体が重ならないので当然）＋ 影の距離の最小値
sh = lambda p: tuple(AA * p[t] - dot(p, A) * A[t] for t in range(3))
def d2(a, b): v = tuple(a[t] - b[t] for t in range(3)); return dot(v, v)
# 輪：軸が A の輪の真ん中の面
rings_by_plane = defaultdict(list)
for key, rr in C3.ringsh.items():
    for r in rr:
        hs = sorted({dot(c2of(n), A) for n in r}, key=lambda z: z.a + 1.618 * z.b)
        rings_by_plane[hs[0] + L2].append(r)
cnt = Counter(len(v) for v in rings_by_plane.values())
print("   一枚の面に乗る 10 個の円環の数の分布:", dict(sorted(cnt.items())))
R2 = None; rel = Counter()
for h, rs in rings_by_plane.items():
    for a, b in itertools.combinations(rs, 2):
        ca = tuple(sum((sh(c2of(n))[t] for n in a), Z()) for t in range(3))
        cb = tuple(sum((sh(c2of(n))[t] for n in b), Z()) for t in range(3))
        rel[str(d2(ca, cb))] += 1
r0 = next(iter(C3.ringsh.values()))[0]
c0 = tuple(sum((sh(c2of(n))[t] for n in r0), Z()) for t in range(3))
R2 = d2(tuple(10 * sh(c2of(next(iter(r0))))[t] for t in range(3)), c0)
print("   円環の半径²（同じ尺度）:", R2)
print("   同じ面の円環どうしの中心の距離²:", dict(rel))
for k in rel:
    z = Z(*[int(x) for x in k.replace('φ', '').split('+')])
    pw = Z(1)
    for e in range(0, 10):
        if z == R2 * pw: print("     %s ＝ φ^%d × 半径²" % (k, e))
        pw = pw * P

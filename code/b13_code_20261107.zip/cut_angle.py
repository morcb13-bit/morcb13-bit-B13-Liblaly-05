"""円環 5 つの中心がなす正五角形の向きを、円環の中の五角形の並び（36° ごと）に対して測る。"""
import json, math
import export_fig as E          # 型（平面の第一層）の 40 個を図の座標で持っている
D = json.load(open("cut_data.json"))
def offset(ring_centers, pent_centers_by_ring):
    out = []
    gc = [sum(c[0] for c in ring_centers) / 5, sum(c[1] for c in ring_centers) / 5]
    for c, pcs in zip(ring_centers, pent_centers_by_ring):
        rad = math.atan2(gc[1] - c[1], gc[0] - c[0])              # 円環から組の中心への向き
        ang = [math.atan2(y - c[1], x - c[0]) for x, y in pcs]   # 円環の中の五角形の向き
        dmin = min(((a - rad) * 180 / math.pi) % 36 for a in ang)
        out.append(round(min(dmin, 36 - dmin), 3))
    return out
# 切り口の組
pcs = [[] for _ in range(5)]
for p in D["pents"]:
    if p["r"] >= 0:
        pcs[p["r"]].append((sum(x for x, y in p["q"]) / 5, sum(y for x, y in p["q"]) / 5))
print("切り口の組：組の中心への向きと、円環の中の五角形の向きのずれ（0〜18°）", offset(D["rc"], pcs))
# 平面の第一層（ring5x10 の 40 個の影）
F = E.D["flat"]["rts"]
units = {}
for r in F:
    for u in r["o"]: units.setdefault(u, []).append((r["p"][0], r["p"][1]))
rcF = [(sum(x for x, y in v) / 10, sum(y for x, y in v) / 10) for k, v in sorted(units.items())]
print("平面の第一層：同じずれ", offset(rcF, [v for k, v in sorted(units.items())]))

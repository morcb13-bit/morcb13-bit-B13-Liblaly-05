# Z[φ] の整数だけの算術（φ²=φ+1）
class Z:
    __slots__=("a","b")
    def __init__(s,a=0,b=0): s.a=a; s.b=b
    def __add__(s,o): o=Z.c(o); return Z(s.a+o.a,s.b+o.b)
    __radd__=__add__
    def __neg__(s): return Z(-s.a,-s.b)
    def __sub__(s,o): return s+(-Z.c(o))
    def __rsub__(s,o): return Z.c(o)-s
    def __mul__(s,o):
        o=Z.c(o); return Z(s.a*o.a+s.b*o.b, s.a*o.b+s.b*o.a+s.b*o.b)
    __rmul__=__mul__
    def __eq__(s,o): o=Z.c(o); return s.a==o.a and s.b==o.b
    def __hash__(s): return hash((s.a,s.b))
    @staticmethod
    def c(o): return o if isinstance(o,Z) else Z(o,0)
    def sign(s):
        p,q=2*s.a+s.b,s.b            # 2x = p + q√5
        if p>=0 and q>=0: return 0 if (p==0 and q==0) else 1
        if p<=0 and q<=0: return -1
        return (1 if p>0 else -1) if p*p>5*q*q else (1 if q>0 else -1)
    def __lt__(s,o): return (s-o).sign()<0
    def __abs__(s): return -s if s.sign()<0 else s
    def __repr__(s): return f"{s.a}{'+' if s.b>=0 else ''}{s.b}φ"
P=Z(0,1)
GEN=[(Z(1),P,Z(0)),(Z(-1),P,Z(0)),(Z(0),Z(1),P),(Z(0),Z(-1),P),(P,Z(0),Z(1)),(P,Z(0),Z(-1))]
def dot(u,v): return u[0]*v[0]+u[1]*v[1]+u[2]*v[2]
def cross(u,v): return (u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
def phys(n):
    x=[Z(),Z(),Z()]
    for k in range(6):
        if n[k]:
            for t in range(3): x[t]=x[t]+GEN[k][t]*n[k]
    return tuple(x)
# 面法線15本（向きの重複を除く）と 2·支持値
NRM=[]
import itertools
for i,j in itertools.combinations(range(6),2):
    n=cross(GEN[i],GEN[j])
    NRM.append(n)
# 15本はすべて別向き（対ごとに1本）
H2=[sum((abs(dot(G,n)) for G in GEN),Z()) for n in NRM]   # 2·RT の支持値（辺長＝生成子）
def overlap(c1,c2):
    d=phys(tuple(c1[t]-c2[t] for t in range(6)))
    return all(abs(dot(d,n))<h for n,h in zip(NRM,H2))
def touch(c1,c2):
    d=phys(tuple(c1[t]-c2[t] for t in range(6)))
    vals=[(abs(dot(d,n))-h).sign() for n,h in zip(NRM,H2)]
    return max(vals)==0 and vals.count(0)==1   # 1つの面だけちょうど・他は内側

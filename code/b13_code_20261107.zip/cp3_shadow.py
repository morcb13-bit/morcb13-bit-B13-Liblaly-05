"""cp3_shadow.py ── CP3：平面の第一層（円環5個・五角形40枚）は、立体のペンローズの輪5つの影か。整数だけ。"""
import json, itertools
from collections import Counter
from zphi import Z, GEN, dot
import ring5x10 as R
import cp2_match as M
U, g, apply, mpow = R.U, R.g, R.apply, R.mpow
B, SYM, app = M.B, M.SYM, M.app
A = GEN[2]; AA = dot(A, A)
def phys(v): return tuple(sum((GEN[k][t] * v[k] for k in range(6)), Z()) for t in range(3))
def shadow(v):                 # 軸 A に垂直な成分 ×|A|²（整数の組）
    p = phys(v); return tuple(AA * p[t] - dot(p, A) * A[t] for t in range(3))
def height(v): return dot(phys(v), A)
# ---- タイリングの輪のうち、軸が e2（＝A）の向きのもの
ringsA = []
c0 = U[0]; diffs = [tuple(c[t] - c0[t] for t in range(6)) for c in U]
for S in SYM:
    p, sg = S
    if p[2] != 2: continue          # 軸の生成子 e2 が e2 に写るもの（向きは ±）
    sd = [app(S, v) for v in diffs]
    for n0 in B:
        pts = [tuple(n0[t] + v[t] for t in range(6)) for v in sd]
        if all(x in B for x in pts): ringsA.append(frozenset(pts))
ringsA = list(set(ringsA))
print("軸が A の向きの輪:", len(ringsA))
key = lambda s: frozenset(shadow(x) for x in s)
ringsh = {}
for r in ringsA: ringsh.setdefault(key(r), []).append(r)
# ---- 平面の第一層の型（ring5x10 の 40 個の置き方、5 つの輪に分けて持つ）
F = [o for o in json.load(open("ring5x10_cands.json")) if o["n"] == 40 and o["ov"] == 10][0]
gk = mpow(g, F["k"]); Q = tuple(F["Q"])
h = lambda x: tuple(apply(gk, x)[t] + Q[t] for t in range(6))
tmpl = [list(U)]
for _ in range(4): tmpl.append([h(x) for x in tmpl[-1]])
def find(tmpl_rings, label):
    hits = []
    for S in SYM:
        p, sg = S
        if p[2] != 2: continue
        T = [[app(S, x) for x in r] for r in tmpl_rings]
        Tsh = [frozenset(shadow(x) for x in r) for r in T]
        base = next(iter(Tsh[0]))
        for rs in ringsh:                       # 型の輪 0 をタイリングの輪に重ねる
            for b in rs:
                d = tuple(b[t] - base[t] for t in range(3))
                moved = [frozenset(tuple(x[t] + d[t] for t in range(3)) for x in s) for s in Tsh]
                if moved[0] != rs: continue
                if all(m in ringsh for m in moved):
                    hits.append(tuple(sorted(tuple(sorted(tuple((v.a, v.b) for v in pt) for pt in m)) for m in moved)))
    hits = set(hits)
    print("%s：見つかった並び %d" % (label, len(hits)))
    return hits
hits = find(tmpl, "平面の第一層（円環5個・五角形40枚）")
# 見つかった並びの、5 つの輪の高さ（輪ごとの30面体の高さの組）
def rings_of(hit):
    out = []
    for m in hit:
        k = frozenset(tuple(Z(a, b) for a, b in pt) for pt in m)
        out.append(ringsh[k])
    return out
if hits:
    ex = next(iter(hits))
    for i, rr in enumerate(rings_of(ex)):
        hs = sorted({str(height(x)) for r in rr for x in r})
        print("   輪 %d：影の合う輪 %d 個・30面体の高さ %s" % (i, len(rr), hs))
# 負の対照：輪 1 つを面の接触 1 歩（輪の中の隣どうしの差）だけずらす
step = tuple(U[1][t] - U[0][t] for t in range(6))
bad = [list(r) for r in tmpl]; bad[2] = [tuple(x[t] + step[t] for t in range(6)) for x in bad[2]]
find(bad, "対照 輪 1 つを 1 歩ずらした並び")

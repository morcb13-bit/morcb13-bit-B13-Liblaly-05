"""B1〜B3：広げた円環 5 つを、つなぎの円環でつなぐ。Z[ζ10] の整数だけで判定。"""
import itertools, math
from collections import Counter
from zphi import Z
import q1_match as Q
import cut_tiling as T
P_ = Z(0, 1)
base = T.R2 * (P_ + 2)
# 図の面と同じ探し方で、φ 倍に広がった円環 5 つの組を選ぶ
found = None
for h, rs in T.rings_by_plane.items():
    cs = [tuple(sum((T.sh(T.c2of(n))[t] for n in r), Z()) for t in range(3)) for r in rs]
    for five in itertools.combinations(range(len(cs)), 5):
        pts = [cs[i] for i in five]
        d = Counter(T.d2(a, b) for a, b in itertools.combinations(pts, 2))
        if len(d) != 2 or sorted(d.values()) != [5, 5]: continue
        a, b = sorted(d, key=lambda z: z.a + 1.618 * z.b)
        if b == a * P_ * P_ and a == base * P_ * P_: found = (h, [rs[i] for i in five]); break
    if found: break
h, five = found
plane = {Q.cutz(n) for n, s in T.planes[h]}
rings = [[Q.cutz(n) for n in r] for r in five]
def zsum(L):
    r = (0, 0, 0, 0)
    for x in L: r = Q.zadd(r, x)
    return r
ten = (10, 0, 0, 0)
cen10 = [zsum(r) for r in rings]                          # 円環の中心 ×10
O = sorted({Q.zsub(Q.zmul(ten, p), c) for r, c in zip(rings, cen10) for p in r})   # 中心から五角形への向き ×10（どの円環も同じ）
print("円環の中の五角形の向き（×10）の種類:", len(O), "（10 なら全部の円環が同じ形）")
# 隣の五角形の距離（＝つなぎの判定の目盛り）
dP = min(Q.n2(Q.zsub(a, b)) for a, b in itertools.combinations(rings[0], 2))
spacing = math.sqrt(dP)
def ring_at(c10): return [Q.zadd(c10, o) for o in O]     # ×10 の座標で
allp10 = {Q.zmul(ten, p) for p in plane}
col10 = [set(Q.zmul(ten, p) for p in r) for r in rings]
colored = set().union(*col10)
# 隣どうしの色つき円環（中心が最も近い組）
dmin = min(Q.n2(Q.zsub(a, b)) for a, b in itertools.combinations(cen10, 2))
pairs = [(i, j) for i, j in itertools.combinations(range(5), 2) if abs(Q.n2(Q.zsub(cen10[i], cen10[j])) - dmin) < 1e-6]
print("隣どうしの色つき円環の組:", len(pairs))
def overlap(new, others):
    for a in new:
        for b in others:
            if a == b: continue
            if Q.n2(Q.zsub(a, b)) < (10 * spacing) ** 2 - 1e-6: return True
    return False
def share_kind(ring_new, c_new, ring_old, c_old):
    sh = sorted(set(ring_new) & set(ring_old))
    if len(sh) != 2: return None
    # 共有する 2 枚が、新しい円環の中で何枚おきか（0 なら連続）
    ang = lambda p, c: math.atan2(Q.zf(Q.zsub(p, c)).imag, Q.zf(Q.zsub(p, c)).real)
    da = abs(math.degrees(ang(sh[0], c_new) - ang(sh[1], c_new))) % 360
    da = min(da, 360 - da)
    return int(round(da / 36)) - 1
bridges = []
for i, j in pairs:
    cands = set()
    for p in col10[i]:
        for o in O: cands.add(Q.zsub(p, o))               # 色つき円環 i の五角形を、新しい円環が持つ置き方
    for c in cands:
        rn = ring_at(c)
        ki = share_kind(rn, c, col10[i], cen10[i]); kj = share_kind(rn, c, col10[j], cen10[j])
        if ki is None or kj is None: continue
        others = colored - set(rn)
        if overlap([p for p in rn if p not in colored], others): continue
        if any(len(set(rn) & col10[k]) for k in range(5) if k not in (i, j)): continue
        bridges.append((i, j, c, ki, kj))
print("B1 つなぎの円環の置き場所:", len(bridges), "／（間に挟む五角形の数：A 側, B 側）",
      dict(Counter((ki, kj) for i, j, c, ki, kj in bridges)))

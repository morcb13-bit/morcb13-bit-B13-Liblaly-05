#  icosian_shells.py  600胞体（単位イコシアン120個）を4番目の座標 w で切った断面
#
#      icosian.py を import する。係数は Q(√5) の Fraction のまま。浮動小数は表示の val() だけ。
#
#      検定（期待値は 2026-08-15 の記録。走らせる前に置いた値）
#        1 断面は 9 枚、頂点数は 1・12・20・12・30・12・20・12・1
#        2 各断面は等半径（xyz の長さ² が断面の中で 1 種類）
#        3 断面の形を最近接の次数で判定：点→正20面体(5)→正12面体(3)→正20面体(5)→12・20面体(4)→（対称に戻る）
#        4 正20面体の殻 2 枚は半径の比がちょうど φ で、内側を φ 倍すると外側の点集合に一致する（向きも同じ）
#        5 正12面体の殻 2 枚（w=±1/2）も同じ向き
#      負の対照
#        4' 内側の正20面体を φ 倍せずに比べると一致しない。φ² 倍でも一致しない
#        3' 断面ではなく 120 点全体の最近接の次数は 12（断面の次数 5・3・4 は切ったから出た値）

from fractions import Fraction as F
from collections import defaultdict
import icosian as I

Q5 = I.Q5
PHI = Q5(0, 1)


def sign(x):
    """a+bφ の符号。2x = (2a+b) + b√5 を、平方の比較だけで決める。"""
    p, q = 2 * x.a + x.b, x.b
    if p >= 0 and q >= 0:
        return 0 if (p == 0 and q == 0) else 1
    if p <= 0 and q <= 0:
        return -1
    return (1 if p > 0 else -1) if p * p > 5 * q * q else (1 if q > 0 else -1)


def less(x, y):
    return sign(x - y) < 0


def d2(u, v):
    s = Q5(0, 0)
    for a, b in zip(u, v):
        s = s + (a - b) * (a - b)
    return s


def key(x):
    """Q5 を並べ替えるための鍵（表示の値。比較そのものは sign で行う）"""
    return x.val()


def main():
    Vs = I.build()
    print("頂点", len(Vs))

    # ---- 断面に分ける
    sl = defaultdict(list)
    for q in Vs:
        sl[q.c[0]].append(tuple(q.c[1:]))
    ws = sorted(sl, key=key, reverse=True)
    counts = [len(sl[w]) for w in ws]
    ok1 = counts == [1, 12, 20, 12, 30, 12, 20, 12, 1]
    print("検定1 断面の頂点数", counts, "OK" if ok1 else "NG")

    # ---- 等半径
    ok2 = True
    rad = []
    for w in ws:
        r = {d2(p, (Q5(0), Q5(0), Q5(0))) for p in sl[w]}
        if len(r) != 1:
            ok2 = False
        rad.append(next(iter(r)))
    print("検定2 各断面が等半径", "OK" if ok2 else "NG")
    for w, r in zip(ws, rad):
        print("   w = %-10s 半径² = %-10s（表示 %.6f）" % (w, r, r.val() ** 0.5))

    # ---- 最近接の次数で形を判定
    def degree(P):
        if len(P) == 1:
            return 0
        dmin = None
        for i in range(len(P)):
            for j in range(i + 1, len(P)):
                d = d2(P[i], P[j])
                if dmin is None or less(d, dmin):
                    dmin = d
        deg = {sum(1 for j in range(len(P)) if j != i and d2(P[i], P[j]) == dmin) for i in range(len(P))}
        return deg.pop() if len(deg) == 1 else None
    name = {0: "点", 5: "正20面体", 3: "正12面体", 4: "12・20面体"}
    degs = [degree(sl[w]) for w in ws]
    want = [0, 5, 3, 5, 4, 5, 3, 5, 0]
    ok3 = degs == want
    print("検定3 次数", degs, "→", "・".join(name.get(d, "?") for d in degs), "OK" if ok3 else "NG")

    # 対照 3'：120 点全体の次数
    allp = [tuple(q.c) for q in Vs]
    print("対照3' 120点全体の最近接の次数", degree(allp), "（12 なら、断面の次数は切ったから出た値）")

    # ---- 正20面体の殻 2 枚
    ico = [w for w, d in zip(ws, degs) if d == 5 and sign(w) > 0]   # w>0 の側の 2 枚
    a, b = sorted(ico, key=lambda w: rad[ws.index(w)].val())
    ra, rb = rad[ws.index(a)], rad[ws.index(b)]
    ratio_ok = rb == ra * PHI * PHI
    inner = set(sl[a]); outer = set(sl[b])
    scaled = {tuple(PHI * x for x in p) for p in inner}
    same = scaled == outer
    print("検定4 正20面体の殻：外の半径² ＝ φ²×内の半径²", "OK" if ratio_ok else "NG",
          "／内を φ 倍すると外に一致", "OK" if same else "NG")
    # 対照 4'
    plain = inner == outer
    sq = {tuple(PHI * PHI * x for x in p) for p in inner} == outer
    print("対照4' φ倍しない／φ²倍で一致するか:", plain, sq, "（どちらも False なら判定は区別をつけている）")

    # ---- 正12面体の殻 2 枚（w=±1/2）
    dod = [w for w, d in zip(ws, degs) if d == 3]
    ok5 = set(sl[dod[0]]) == set(sl[dod[1]])
    print("検定5 正12面体の殻 2 枚が同じ点集合（同じ向き）", "OK" if ok5 else "NG", " w =", dod)

    # 4 枚の正20面体の殻（w=±の2組）がすべて同じ向きか（単位化は φ 倍の比較で代える）
    icos = [w for w, d in zip(ws, degs) if d == 5]
    sets = [set(sl[w]) for w in icos]
    same_pm = sets[0] == sets[3] and sets[1] == sets[2]
    print("   正20面体の殻 4 枚：w と −w の組は同じ点集合", same_pm)

    allok = ok1 and ok2 and ok3 and ratio_ok and same and ok5 and not plain and not sq
    print("\n総合", "OK" if allok else "NG")


if __name__ == "__main__":
    main()

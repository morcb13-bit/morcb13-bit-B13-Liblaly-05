#  cell600_string.py  正四面体の紐を 600 胞体の中で作る／辺のまわりの輪（2026-10-06 の pair2n の作り直し）
#
#      600 胞体の頂点 120 個を a＋bφ（a, b は整数）だけで持つ（半径 2）。
#          (±2,0,0,0) の並べ替え 8 個、(±1,±1,±1,±1) 16 個、(±φ,±1,±(φ−1),0) の偶置換 96 個
#      隣り合う頂点の内積は 2φ。
#
#      検定（期待値は 2026-10-06 の記録）
#        C1  頂点 120・辺 720・正四面体 600
#        C2  紐の規則は 3 次元と同じ（直前の 3 頂点の三角形を共有する、もう一つの正四面体へ。最古の頂点には戻らない）。
#            正四面体 30 個でちょうど最初の正四面体に戻り、紐に現れる頂点も 30 個
#        C3  600 胞体の中では、どの辺のまわりにも正四面体がちょうど 5 個集まる
#        E1  3 次元で一本の辺のまわりに正四面体を 5 個並べると隙間が残る：cos（隙間）＝ 241/243、半角の sin² ＝ 1/3⁵
#      対照
#        E1' 立方体 4 個、正四面体・正八面体の交互 4 個は、どちらも隙間 0（閉じる）
#        C2' 3 次元の紐（tetra_string.py）は 300 段まで閉じない
from itertools import permutations, product, combinations
from fractions import Fraction as F
from zphi import Z

P = Z(0, 1)
def par(p):
    return sum(1 for i in range(4) for j in range(i+1, 4) if p[i] > p[j]) % 2
def dot(u, v):
    s = Z()
    for a, b in zip(u, v): s = s + a * b
    return s

V = set()
for i in range(4):
    for s in (2, -2):
        c = [Z()] * 4; c[i] = Z(s); V.add(tuple(c))
for sg in product((1, -1), repeat=4):
    V.add(tuple(Z(x) for x in sg))
base = [P, Z(1), P - 1, Z()]
for p in permutations(range(4)):
    if par(p): continue
    for sg in product((1, -1), repeat=3):
        c = [Z()] * 4
        vals = [base[0]*sg[0], base[1]*sg[1], base[2]*sg[2], Z()]
        for k in range(4): c[p[k]] = vals[k]
        V.add(tuple(c))
V = sorted(V, key=lambda v: tuple((x.a, x.b) for x in v))
idx = {v: i for i, v in enumerate(V)}
E2 = P * 2
adj = [set() for _ in V]
for i, j in combinations(range(len(V)), 2):
    if dot(V[i], V[j]) == E2:
        adj[i].add(j); adj[j].add(i)
nE = sum(len(a) for a in adj) // 2
tets = set()
for i in range(len(V)):
    for j in adj[i]:
        if j < i: continue
        for k in adj[i] & adj[j]:
            if k < j: continue
            for l in adj[i] & adj[j] & adj[k]:
                if l < k: continue
                tets.add((i, j, k, l))
ok1 = (len(V), nE, len(tets)) == (120, 720, 600)
print("C1 頂点・辺・正四面体", len(V), nE, len(tets), "OK" if ok1 else "NG")

# C2 紐
start = sorted(tets)[0]
w = list(start)
seen_v = set(w)
close = None
for step in range(1, 200):
    a, b, c = w[-3], w[-2], w[-1]
    cand = (adj[a] & adj[b] & adj[c]) - {w[-4]}
    assert len(cand) == 1, cand          # 三角形を共有する正四面体はちょうど 2 個
    w.append(cand.pop()); seen_v.add(w[-1])
    if set(w[-4:]) == set(start):
        close = step; break
ok2 = close == 30 and len(seen_v) == 30
print("C2 紐が最初の正四面体に戻る段", close, "／現れる頂点", len(seen_v), "OK" if ok2 else "NG")

# C3 辺のまわりの正四面体
around = {}
for t in tets:
    for e in combinations(t, 2):
        around[e] = around.get(e, 0) + 1
ok3 = set(around.values()) == {5}
print("C3 辺のまわりの正四面体の数", set(around.values()), "OK" if ok3 else "NG")

# E1 3 次元の辺のまわり：二面角の cos と sin を (c, s/√8) の分数の組で持って合成する
def mul(x, y):          # (c1,s1)(c2,s2)、sin は √8 を括り出して持つ：sin = s·√8
    return (x[0]*y[0] - 8*x[1]*y[1], x[0]*y[1] + x[1]*y[0])
tet = (F(1, 3), F(1, 3))          # cos 70.53° ＝ 1/3、sin ＝ √8/3
octa = (F(-1, 3), F(1, 3))        # cos 109.47° ＝ −1/3、sin ＝ √8/3
r = (F(1), F(0))
for _ in range(5): r = mul(r, tet)
gap_cos = r[0]                     # 隙間 ＝ 360° − 5θ、cos は同じ
half_sin2 = (1 - gap_cos) / 2
okE = gap_cos == F(241, 243) and half_sin2 == F(1, 243)
print("E1 正四面体 5 個：cos（隙間）", gap_cos, "／半角の sin²", half_sin2, "OK" if okE else "NG")
r = (F(1), F(0))
for x in (tet, octa, tet, octa): r = mul(r, x)
cube = (F(0), F(1, 1))             # 90°：cos 0、sin 1（ここだけ √8 を括らずに直接）
print("対照 E1' 正四面体・正八面体の交互 4 個：(cos, sin/√8) ＝", r, "（(1,0) なら閉じる）")
print("対照 E1' 立方体 4 個：二面角 90° を 4 回で 360°（隙間 0）")
print("\n総合", "OK" if ok1 and ok2 and ok3 and okE and r == (1, 0) else "NG")

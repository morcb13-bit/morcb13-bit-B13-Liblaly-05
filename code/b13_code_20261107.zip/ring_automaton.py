"""ring_automaton.py ── 円環を 5 回対称の組で置いていくオートマトン。重なり 0・5 回回転対称を保って、どこまで埋まるか。
位置は Z[ζ10] の整数4つ（×50、組の中心が原点）。回転は ζ² を掛けるだけ。
重なりの判定：五角形の中心が同じなら同じ五角形（共有）。違うなら、正五角形どうしの交わりを分離軸で調べる（ここだけ小数）。"""
import itertools, math, sys
from collections import Counter, defaultdict
import q1_match as Q
import bridge as Bm
import bridge2 as B2
import cut_plane as CP
import cut_tiling as T
from zphi import GEN, dot, Z
ZERO = (0, 0, 0, 0)
g = ZERO
for c in Bm.cen10: g = Q.zadd(g, c)                       # 50 × 組の中心
to50 = lambda p10: Q.zsub(Q.zmul((5, 0, 0, 0), p10), g)
R72 = Q.zpow(2)
def rot(p, k):
    for _ in range(k % 5): p = Q.zmul(R72, p)
    return p
P_ = Z(0, 1); L2 = (Z(1) + P_ * 2) * 2
def verts(sign):
    out = []
    for s in CP.VS:
        if dot(CP.OFF[s], GEN[2]) == L2 * sign:
            z = ZERO
            for k, j in Q.J.items(): z = Q.zadd(z, tuple(s[k] * x for x in Q.zpow(j)))
            out.append(Q.zmul((50, 0, 0, 0), z))           # 頂点の向き（×50）
    return out
VLO, VHI = verts(-1), verts(1)
# 色つき円環の五角形：中心と向き
sideof = {Q.cutz(n): s for n, s in T.planes[Bm.h]}
O50 = {}
for r, c10 in zip(Bm.rings, Bm.cen10):
    for p in r:
        o = Q.zsub(Q.zmul((50, 0, 0, 0), p), Q.zmul((5, 0, 0, 0), c10))
        O50[o] = VLO if sideof[p] == "上の段" else VHI    # 上の段の塊は、下側の五角形で切れる
assert len(O50) == 10
def ring_pents(c50): return {Q.zadd(c50, o): vs for o, vs in O50.items()}
# ---- 五角形の重なり（小数）
def poly(c, vs):
    zc = Q.zf(c); return [Q.zf(Q.zadd(c, v)) for v in vs]
def ordered(ps):
    m = sum(ps) / len(ps); return sorted(ps, key=lambda z: math.atan2((z - m).imag, (z - m).real))
def sat_overlap(A, B):
    for P in (A, B):
        n = len(P)
        for i in range(n):
            e = P[(i + 1) % n] - P[i]; ax = complex(-e.imag, e.real)
            pa = [(z.real * ax.real + z.imag * ax.imag) for z in A]
            pb = [(z.real * ax.real + z.imag * ax.imag) for z in B]
            if max(pa) <= min(pb) + 1e-7 * abs(ax) or max(pb) <= min(pa) + 1e-7 * abs(ax): return False
    return True
SPAN = max(abs(Q.zf(v)) for v in VLO) * 2.0001
class World:
    def __init__(self):
        self.rings = []; self.pent = {}; self.grid = defaultdict(list)
    def key(self, c): z = Q.zf(c); return (int(z.real // SPAN), int(z.imag // SPAN))
    def near(self, c):
        kx, ky = self.key(c)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                yield from self.grid[(kx + dx, ky + dy)]
    def can_add(self, c50, check=True):
        new = ring_pents(c50)
        share = Counter()
        for p, vs in new.items():
            if p in self.pent:
                for ri in self.pent[p][1]: share[ri] += 1
                continue
            if not check: continue
            A = ordered(poly(p, vs))
            for q in self.near(p):
                if q == p or q in new: continue
                if abs(Q.zf(q) - Q.zf(p)) >= SPAN: continue
                if sat_overlap(A, ordered(poly(q, self.pent[q][0]))): return None
        if any(v not in (2,) for v in share.values()): return None if check else share
        return share
    def add(self, c50):
        ri = len(self.rings); self.rings.append(c50)
        for p, vs in ring_pents(c50).items():
            if p in self.pent: self.pent[p][1].append(ri)
            else: self.pent[p] = (vs, [ri]); self.grid[self.key(p)].append(p)
def start(kind):
    W = World()
    for c10 in Bm.cen10: W.add(Q.zmul((5, 0, 0, 0), c10) if False else to50(c10) if False else Q.zsub(Q.zmul((5, 0, 0, 0), c10), g))
    for key, bs in B2.classes.items():
        if key[:2] == kind:
            for a, b, c in bs: W.add(Q.zsub(Q.zmul((5, 0, 0, 0), c), g))
    return W
def candidates(W):
    cand = set()
    for p in list(W.pent):
        for o in O50: cand.add(Q.zsub(p, o))
    cand -= set(W.rings)
    return cand
def grow(W, Rmax, steps, check=True, log=True):
    rejected = 0
    for st in range(steps):
        best = None
        for c in sorted(candidates(W), key=lambda c: abs(Q.zf(c))):
            if abs(Q.zf(c)) > Rmax: break
            orbit = [rot(c, k) for k in range(5)]
            # 一組まるごと置けるか（置きながら確かめる）
            trial = World(); trial.rings = list(W.rings); trial.pent = {k: (v[0], list(v[1])) for k, v in W.pent.items()}
            trial.grid = defaultdict(list, {k: list(v) for k, v in W.grid.items()})
            ok = True
            for o in orbit:
                if o in trial.rings: continue
                sh = trial.can_add(o, check)
                if sh is None or (check and not sh): ok = False; break
                trial.add(o)
            if ok: best = trial; break
            rejected += 1
        if best is None:
            return st, rejected
        W.rings, W.pent, W.grid = best.rings, best.pent, best.grid
        if log and st % 5 == 0:
            print("   段 %3d：円環 %4d・五角形 %5d・いちばん外の円環の半径 %.1f" % (st, len(W.rings), len(W.pent), max(abs(Q.zf(c)) for c in W.rings) / 50))
    return steps, rejected
if __name__ == "__main__":
    Rmax = float(sys.argv[1]) * 50 if len(sys.argv) > 1 else 40 * 50
    for kind in ((0, 2), (2, 0)):
        W = start(kind)
        print("出発（2 枚おきを %s 側）：円環 %d・五角形 %d" % ("B" if kind == (0, 2) else "A", len(W.rings), len(W.pent)))
        n, rej = grow(W, Rmax, 400)
        rings = W.rings
        sym = all(rot(c, 1) in set(rings) for c in rings)
        print("   止まった段 %d・円環 %d・五角形 %d・5 回回転で自分に写る %s・置けずに退けた組 %d" % (n, len(rings), len(W.pent), sym, rej))

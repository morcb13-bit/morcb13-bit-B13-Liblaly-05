"""CP1 ── 紐の30面体の中心が、6次元→3次元のカットアンドプロジェクトの一部か。
残渣の側：生成子の φ を 1−φ（＝−1/φ）に置き換えた G'。窓 W ＝ G' の ±1/2 のゾノトープ（ひし形30面体）。
点の集まりが「ある γ で全部 W+γ に入る」⇔ 部分集合として出てくる。
判定：(a) 15 方向それぞれの幅（必要条件）、(b) γ の範囲が空でないか（フーリエ・モツキンで十分条件）。
すべて Z[φ] の整数と分数の比較だけ。"""
import json, itertools, functools
from zphi import *
import core_hollow as C
import ring5x10 as R
U,g,apply,mpow=R.U,R.g,R.apply,R.mpow
conj=lambda z: Z(z.a+z.b,-z.b)            # φ → 1−φ
Gp=[tuple(conj(c) for c in v) for v in GEN]
# T0：実の側と残渣の側が6次元で直交しているか
ok0=all(sum((GEN[k][i]*Gp[k][j] for k in range(6)),Z())==Z(0) for i in range(3) for j in range(3))
print("T0 実と残渣が直交:", "OK" if ok0 else "NG")
def perp(n):
    x=[Z(),Z(),Z()]
    for k in range(6):
        if n[k]:
            for t in range(3): x[t]=x[t]+Gp[k][t]*n[k]
    return tuple(x)
M=[cross(Gp[i],Gp[j]) for i,j in itertools.combinations(range(6),2)]
W2=[sum((abs(dot(G,m)) for G in Gp),Z()) for m in M]          # 窓の幅（= 2·支持値）
def widths_ok(pts):
    bad=0
    for m,w in zip(M,W2):
        v=[dot(p,m) for p in pts]
        mx=functools.reduce(lambda a,b: a if b<a else b, v); mn=functools.reduce(lambda a,b: b if b<a else a, v)
        if not ((mx-mn)-w).sign()<=0: bad+=1
    return bad
Fr=C.Fr
def det3(r0,r1,r2):
    return (r0[0]*(r1[1]*r2[2]-r1[2]*r2[1]) - r0[1]*(r1[0]*r2[2]-r1[2]*r2[0]) + r0[2]*(r1[0]*r2[1]-r1[1]*r2[0]))
def fm_feasible(pts):
    """x＝2γ が  a·x ≤ b （30本）を満たすか。領域は有界なので、空でなければ頂点がある。
    3本の平面の交点（クラメルの公式、Z[φ] の行列式）を全部試し、残りの式を分母を払って確かめる。"""
    ineq=[]
    for m,w in zip(M,W2):
        v=[dot(p,m)*2 for p in pts]
        mx=functools.reduce(lambda a,b: a if b<a else b, v); mn=functools.reduce(lambda a,b: b if b<a else a, v)
        ineq.append((m, mn+w)); ineq.append((tuple(-c for c in m), -(mx-w)))
    for (a1,b1),(a2,b2),(a3,b3) in itertools.combinations(ineq,3):
        d=det3(a1,a2,a3)
        if d.sign()==0: continue
        dx=[det3(*[ [ (bb if t==col else aa[t]) for t in range(3)] for aa,bb in ((a1,b1),(a2,b2),(a3,b3))]) for col in range(3)]
        sd=d.sign()
        if all(((sum((a[t]*dx[t] for t in range(3)),Z()) - b*d).sign()*sd)<=0 for a,b in ineq):
            return True
    return False
def judge(name,cents):
    pts=[perp(c) for c in cents]
    wb=widths_ok(pts)
    fe=fm_feasible(pts) if wb==0 else False
    print("%-34s 点 %3d  幅で外れる方向 %2d/15  窓に収まる γ %s  → %s"%(name,len(cents),wb,
          "あり" if fe else "なし", "部分集合（OK）" if fe else "部分集合ではない"))
# ---- 正の対照：本物のカットアンドプロジェクトで選んだ点
D=1000; gam=(Z(3,1),Z(-2,5),Z(7,-3))     # D·γ（一般の位置）
acc=[]
for n in itertools.product(range(-2,3),repeat=6):
    p=perp(n)
    if all(((abs(dot(tuple(p[t]*D-gam[t] for t in range(3)),m))*2)-w*D).sign()<0 for m,w in zip(M,W2)):
        acc.append(n)
import random; random.seed(1)
judge("対照＋ 窓で選んだ点（一部 60 個）",random.sample(acc,min(60,len(acc))))
judge("対照－ 窓を無視した格子点 60 個",random.sample(list(itertools.product(range(-2,3),repeat=6)),60))
# ---- 本題
H=json.load(open("helix5x10.json"))
def chain(k,Q,nunits):
    h=C.screw(k,tuple(Q)); us=[list(U)]
    for _ in range(nunits-1): us.append([h(x) for x in us[-1]])
    return sorted(set(x for u in us for x in u))
judge("単位：30面体10個の輪",U)
F=[o for o in json.load(open("ring5x10_cands.json")) if o["n"]==40 and o["ov"]==10][0]
judge("平面のまま閉じた40個",[tuple(c) for c in F["centers6"]])
for kk in (1,2):
    o=[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
    for nu in (2,5,10):
        judge("紐 %d°・輪 %d 個"%(72*kk,nu),chain(kk,o["Q"],nu))
bad=[o for o in H if o["share"]==2 and o["ov"]>0][:2]
for o in bad: judge("食い込む紐（%d組）・輪 5 個"%o["ov"],chain(o["k"],o["Q"],5))

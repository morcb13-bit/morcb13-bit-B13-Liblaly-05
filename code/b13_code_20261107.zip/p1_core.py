#  p1_core.py  検定P1：正四面体と、その点対称の鏡像を重ねた芯（2026-10-10 の作り直し）
#      正四面体を「面の外向き法線 n_i について n_i·x ≤ h」の 4 枚で書き、鏡像は符号を反転した 4 枚。
#      芯の頂点 ＝ 8 枚の平面から 3 枚選んだ交点（クラメルの公式、分数のまま）のうち、全部の不等式を満たすもの。
#      期待値：芯の頂点は 6 個で、x・y・z の軸に ± 一対ずつ乗る正八面体（3 本の軸が互いに直交）
#      対照：正四面体でない四面体（頂点を一つずらす）では、芯の ± の対どうしが直交しない → NG が返る
from fractions import Fraction as F
from itertools import combinations
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det(a, b, c): return dot(a, cross(b, c))
def halfspaces(T):
    c = tuple(F(sum(p[i] for p in T), 4) for i in range(3))
    H = []
    for i in range(4):
        a, b, d = [T[j] for j in range(4) if j != i]
        n = cross(sub(b, a), sub(d, a))
        if dot(n, sub(T[i], a)) > 0: n = tuple(-x for x in n)     # 外向き
        H.append((n, dot(n, a)))
    return H, c
def core(T):
    H, c = halfspaces(T)
    M = [(tuple(-x for x in n), dot(tuple(-x for x in n), tuple(2*ci for ci in c)) + h) for n, h in H]  # 重心に関する点対称
    A = H + M
    pts = set()
    for (n1, h1), (n2, h2), (n3, h3) in combinations(A, 3):
        D = det(n1, n2, n3)
        if D == 0: continue
        cols = [(n1[i], n2[i], n3[i]) for i in range(3)]
        x = []
        for k in range(3):
            m = [list(n1), list(n2), list(n3)]
            for r, hh in enumerate((h1, h2, h3)): m[r][k] = hh
            x.append(F(det(*[tuple(row) for row in m]), D))
        x = tuple(x)
        if all(dot(n, x) <= h for n, h in A): pts.add(x)
    return pts, c
def judge(T, name):
    pts, c = core(T)
    rel = {tuple(p[i] - c[i] for i in range(3)) for p in pts}
    pairs = []
    for p in rel:
        q = tuple(-x for x in p)
        if q in rel and q not in pairs: pairs.append(p)
    orth = all(dot(a, b) == 0 for a, b in combinations(pairs, 2))
    ok = len(rel) == 6 and len(pairs) == 3 and orth
    print("%s：芯の頂点 %d・±の対 %d・対どうし直交 %s → %s" % (name, len(rel), len(pairs), orth, "正八面体（OK）" if ok else "NG"))
    return ok
T = [tuple(F(x) for x in p) for p in [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]]
ok = judge(T, "正四面体")
Tbad = [tuple(F(x) for x in p) for p in [(1, 1, 2), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]]
bad = judge(Tbad, "対照 頂点を一つずらした四面体")
print("総合", "OK" if ok and not bad else "NG")

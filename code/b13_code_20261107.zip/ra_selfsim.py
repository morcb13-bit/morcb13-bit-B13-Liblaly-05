"""I1：60 歩の敷き詰めの円環の中心の中に、出発の形（円環 10 個）と 3 歩目の形（円環 25 個）が φ 倍でそのまま入っているか。
整数の等号だけで判定。回転（36° ごと）・鏡映・平行移動を含める。"""
import json
import q1_match as Q
import ring_automaton as RA
D = json.load(open("ra60.json"))
C = [tuple(c) for c in D["rings"]]; Cs = set(C)
W0 = RA.start((0, 2)); t10 = list(W0.rings)
W3 = RA.start((0, 2)); RA.grow(W3, 10 ** 9, 3, log=False); t25 = list(W3.rings)
SC = {"1（正の対照）": (1, 0, 0, 0), "φ": (1, 0, 1, -1), "φ²": (2, 0, 1, -1), "2（対照）": (2, 0, 0, 0)}
def find(tmpl, s):
    hits = set()
    T = [Q.zmul(s, t) for t in tmpl]
    for refl in (False, True):
        TT = [Q.conj(t) for t in T] if refl else T
        for k in range(10):
            r = Q.zpow(k); TR = [Q.zmul(r, t) for t in TT]
            for c in C:
                d = Q.zsub(c, TR[0])
                img = [Q.zadd(t, d) for t in TR]
                if all(x in Cs for x in img): hits.add(frozenset(img))
    return hits
for name, tm in (("出発の形（円環 10 個）", t10), ("3 歩目の形（円環 25 個）", t25)):
    for sn, s in SC.items():
        h = find(tm, s)
        cen = [sum(Q.zf(x) for x in H) / len(H) for H in h]
        print("%s を %s 倍：見つかった数 %d %s" % (name, sn, len(h), ("（中心が原点のもの %d）" % sum(1 for z in cen if abs(z) < 1e-6)) if h else ""))

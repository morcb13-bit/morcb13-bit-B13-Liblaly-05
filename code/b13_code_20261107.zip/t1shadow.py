from zphi import *
import json
U=[tuple(c) for c in json.load(open("kabai_ring.json"))["rings"]["10"]["centers6"]]
A=GEN[2]; AA=dot(A,A)
def perp(p): return tuple(AA*p[t]-dot(p,A)*A[t] for t in range(3))
cen=[sum(u[t] for u in U) for t in range(6)]
R=[perp(phys(tuple(10*u[t]-cen[t] for t in range(6)))) for u in U]
R2=dot(R[0],R[0])
d2=sorted({dot(tuple(R[i][t]-R[j][t] for t in range(3)),tuple(R[i][t]-R[j][t] for t in range(3))) for i in range(10) for j in range(i+1,10)},key=lambda z:z.a+1.618*z.b)
print("半径²",R2,"中心間距離²（短い順）",d2[:3])
# 円環なら 半径² = φ² × 隣の間隔²  （R=φ², 間隔=φ）
print("半径² − φ²·間隔² =", R2 - Z(1,1)*d2[0])
# 高さの交互：隣（水平で一番近い）どうしの高さが違うか
hs=[dot(phys(u),A) for u in U]
alt=all(hs[i]!=hs[j] for i in range(10) for j in range(10) if i<j and dot(tuple(R[i][t]-R[j][t] for t in range(3)),tuple(R[i][t]-R[j][t] for t in range(3)))==d2[0])
print("水平で隣どうしは上下が入れ替わる:",alt, " 上の段",hs.count(hs[0]),"個")

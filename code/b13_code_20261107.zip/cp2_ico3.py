import itertools
from fractions import Fraction as F
from collections import Counter
from zphi import Z, GEN, dot
import cp2_ico as I
import ring5x10 as R
icos = [(sorted(p), s) for (p, n), (o, s) in zip(I.clusters, I.ok) if o]
def ph(v): return tuple(sum((GEN[k][t] * v[k] for k in range(6)), Z()) for t in range(3))
def d2v(v): x = ph(v); return dot(x, x)
p, s = icos[0]
rad12 = d2v(tuple(12 * p[0][t] - s[t] for t in range(6)))          # ×144
dist = Counter(d2v(tuple(a[t] - b[t] for t in range(6))) for a, b in itertools.combinations(p, 2))
step = min((d2v(tuple(a[t] - b[t] for t in range(6))) for a, b in itertools.combinations(R.U, 2)), key=lambda z: z.a + 1.618 * z.b)
print("中心から30面体の中心までの距離²（×144）:", rad12, " → ×1:", F(rad12.a, 144), "+", F(rad12.b, 144), "φ")
print("正二十面体の中の距離²と個数:", {str(k): v for k, v in dist.items()})
print("輪の中で面で接する一歩の距離²:", step)
edge = min(dist, key=lambda z: z.a + 1.618 * z.b)
print("正二十面体の辺 ＝ 面で接する一歩:", edge == step)
# 中心どうしの最短距離² と 半径² の比が φ の冪か
cen = [c for _, c in icos]
dmin = min((d2v(tuple(a[t] - b[t] for t in range(6))) for a, b in itertools.combinations(cen, 2)), key=lambda z: z.a + 1.618 * z.b)
print("中心どうしの最短距離²（×144）:", dmin)
P = Z(0, 1)
pw = Z(1)
for k in range(0, 12):
    if dmin == rad12 * pw: print("   最短距離² ＝ φ^%d × 半径²" % k)
    if dmin == rad12 * pw * 4: print("   最短距離² ＝ 4·φ^%d × 半径²" % k)
    pw = pw * P
# 中心どうしの差（6次元）の種類：近い組の向き
from collections import defaultdict
near = [(a, b) for a, b in itertools.combinations(cen, 2) if d2v(tuple(a[t] - b[t] for t in range(6))) == dmin]
print("最短の組", len(near), " 差の例（÷12）:", [F(near[0][0][t] - near[0][1][t], 12) for t in range(6)])

"""cp2_tiling.py ── 6次元→3次元のカットアンドプロジェクトで黄金のひし面体のタイリングを作る。
判定はすべて a＋bφ の整数と分数。浮動小数は使わない。
  T0 タイリングか：内側の面はちょうど2つのひし面体に属する／体積は2種類で比 φ
     対照：窓を1.3倍にして「8頂点がすべて窓に入る」で選ぶと、面が3つ以上に属するところが出る
  T1 30面体の塊：6次元の単位立方体 n+[0,1]^6 の中に、20通りの3本組のひし面体がちょうど1つずつ入る場所
"""
import itertools, json, sys
from zphi import Z, GEN, dot, cross
P = Z(0, 1)
conj = lambda z: Z(z.a + z.b, -z.b)
Gp = [tuple(conj(c) for c in v) for v in GEN]
def lin(G, n):
    x = [Z(), Z(), Z()]
    for k in range(6):
        if n[k]:
            for t in range(3): x[t] = x[t] + G[k][t] * n[k]
    return tuple(x)
phys = lambda n: lin(GEN, n)
perp = lambda n: lin(Gp, n)
M = [cross(Gp[i], Gp[j]) for i, j in itertools.combinations(range(6), 2)]
W2 = [sum((abs(dot(G, m)) for G in Gp), Z()) for m in M]
D = 1000
GAM = (Z(3, 1), Z(-2, 5), Z(7, -3))          # D·γ（一般の位置）
def accepted(n, scale=(1, 1)):
    p = perp(n); a, b = scale
    for m, w in zip(M, W2):
        v = dot(tuple(p[t] * D - GAM[t] for t in range(3)), m) * 2
        if not ((abs(v) * b - w * (D * a)).sign() < 0): return False
    return True
def det3(a, b, c): return dot(a, cross(b, c))
TRI = list(itertools.combinations(range(6), 3))
COMP = {T: tuple(k for k in range(6) if k not in T) for T in TRI}
DETC = {T: det3(*[Gp[b] for b in COMP[T]]) for T in TRI}
def tile_selected(n, T):
    """面 n + span(e_T) の双対（残り3本の平行六面体、面の中心から ±1/2）が γ を含むか"""
    c2 = tuple(2 * n[k] + (1 if k in T else 0) for k in range(6))
    pc = perp(c2)
    rhs = tuple(GAM[t] * 2 - pc[t] * D for t in range(3))      # 2D(γ − π⊥(中心))
    a, b, c = [Gp[k] for k in COMP[T]]
    d = DETC[T]
    for col in range(3):
        cols = [list(a), list(b), list(c)]
        cols[col] = list(rhs)
        db = det3(*[tuple(x) for x in cols])
        if not ((abs(db) - abs(d) * D).sign() < 0): return False
    return True

def build(R2, rule="dual", scale=(1, 1)):
    # 窓に入る点を、単位の一歩でつないで広げる（実の側で原点から |x|² < R2）
    start = None
    for n in itertools.product(range(-1, 2), repeat=6):
        if accepted(n, scale): start = n; break
    seen = {start}; todo = [start]
    while todo:
        n = todo.pop()
        for k in range(6):
            for s in (1, -1):
                m = list(n); m[k] += s; m = tuple(m)
                if m in seen: continue
                x = phys(m)
                if (dot(x, x) - R2).sign() >= 0: continue
                if accepted(m, scale): seen.add(m); todo.append(m)
    pts = seen
    tiles = []
    for n in pts:
        for T in TRI:
            verts = [tuple(n[k] + (1 if (k in T and (mask >> T.index(k)) & 1) else 0) for k in range(6)) for mask in range(8)]
            if not all(v in pts for v in verts): continue
            if rule == "dual":
                if tile_selected(n, T): tiles.append((n, T))
            else:
                tiles.append((n, T))
    return pts, tiles

def faces_of(n, T):
    out = []
    for i, j in itertools.combinations(T, 2):
        k = [x for x in T if x not in (i, j)][0]
        for s in (0, 1):
            m = list(n); m[k] += s
            out.append((tuple(m), (i, j)))
    return out

def t0(pts, tiles, R2in, name):
    cnt = {}
    for n, T in tiles:
        for f in faces_of(n, T): cnt[f] = cnt.get(f, 0) + 1
    inner = {}
    for (m, (i, j)), c in cnt.items():
        cen = tuple(2 * m[k] + (1 if k in (i, j) else 0) for k in range(6))
        x = phys(cen)
        if (dot(x, x) - R2in * 4).sign() < 0:
            inner[c] = inner.get(c, 0) + 1
    vols = {}
    for n, T in tiles:
        v = abs(det3(*[GEN[k] for k in T])); vols[v] = vols.get(v, 0) + 1
    print("%s：窓に入る点 %d・ひし面体 %d・内側の面が属するひし面体の数 %s・体積 %s"
          % (name, len(pts), len(tiles), dict(sorted(inner.items())), {str(k): v for k, v in vols.items()}))
    return inner, vols

if __name__ == "__main__":
    R2 = Z(int(sys.argv[1]) if len(sys.argv) > 1 else 60)
    R2in = Z(int(sys.argv[2]) if len(sys.argv) > 2 else 30)
    pts, tiles = build(R2)
    inner, vols = t0(pts, tiles, R2in, "双対で選ぶ")
    ks = list(vols)
    ratio = len(ks) == 2 and (ks[0] == ks[1] * P or ks[1] == ks[0] * P)
    ok0 = set(inner) == {2} and ratio
    print("T0", "OK" if ok0 else "NG", "（内側の面はすべて2つ、体積2種類で比 φ）" if ok0 else "")
    pts_b, tiles_b = build(R2, rule="all8")
    t0(pts_b, tiles_b, R2in, "参考 8頂点が窓に入るだけで選ぶ")
    pts_c, tiles_c = build(R2, rule="all8", scale=(13, 10))
    inner_c, _ = t0(pts_c, tiles_c, R2in, "対照 窓を1.3倍にして8頂点で選ぶ")
    print("対照", "NG を返せる（2 以外が出る）" if set(inner_c) != {2} else "区別がつかない")
    # T1 30面体の塊
    bucket = {}
    for n, T in tiles:
        C = COMP[T]
        for mask in range(8):
            base = list(n)
            for t, k in enumerate(C):
                if (mask >> t) & 1: base[k] -= 1
            bucket.setdefault(tuple(base), []).append(T)
    rts = [n for n, Ts in bucket.items() if len(Ts) == 20 and len(set(Ts)) == 20]
    print("T1 ひし面体20個がちょうど埋める30面体の塊:", len(rts))
    json.dump({"pts": [list(p) for p in pts], "tiles": [[list(n), list(T)] for n, T in tiles], "rts": [list(n) for n in rts]},
              open("cp2_tiling.json", "w"))

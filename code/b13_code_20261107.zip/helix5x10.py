"""helix5x10.py ── 30面体10個の輪を5個、芯のまわりにずらしながら並べる。
h(x)=g^k x+Q。5回で軸方向の平行移動だけに戻るもの（ずらし≠0）を探す。
判定は Z[φ] の整数だけ。"""
import json, itertools
from zphi import *
import ring5x10 as R
U,g,apply,mpow,A,perp=R.U,R.g,R.apply,R.mpow,R.A,R.perp
TURNS=3
def build(gk,Q,n):
    h=lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
    units=[list(U)]
    for _ in range(n-1): units.append([h(x) for x in units[-1]])
    return units
out=[]
for k in (1,2,3,4):
    gk=mpow(g,k)
    S5=[[sum(mpow(gk,j)[r][c] for j in range(5)) for c in range(6)] for r in range(6)]
    for Q in {tuple(b[t]-apply(gk,a)[t] for t in range(6)) for a in U for b in U}:
        T=tuple(sum(S5[r][c]*Q[c] for c in range(6)) for r in range(6))
        pv=perp(phys(T))
        if any(z!=Z(0) for z in pv): continue          # 5回で横にずれない
        units=build(gk,Q,5*TURNS)
        if set(units[1])==set(U): continue
        share=len(set(units[0])&set(units[1]))
        allc=sorted(set(x for u in units for x in u))
        ov=[(i,j) for i in range(len(allc)) for j in range(i+1,len(allc)) if overlap(allc[i],allc[j])]
        pitch=dot(phys(T),A)
        out.append(dict(k=k,Q=Q,shift=T,pitch=pitch,share=share,n=len(allc),ov=len(ov),
                        share5=len(set(units[0])&set(units[5]))))
print("候補 %d（5回で軸方向に戻るもの、ずらし0も含む）"%len(out))
seen=set()
for o in sorted(out,key=lambda o:(o["ov"],o["share"]!=2)):
    key=(o["k"],o["share"],o["n"],o["ov"],o["pitch"])
    if key in seen: continue
    seen.add(key)
    print("  k=%d Q=%s 一周のずらし(×|A|²)=%s 隣と共有%d 一周後と共有%d 30面体%d(%d周) 食い込み%d"
          %(o["k"],o["Q"],o["pitch"],o["share"],o["share5"],o["n"],TURNS,o["ov"]))
json.dump([{**o,"pitch":[o["pitch"].a,o["pitch"].b]} for o in out],open("helix5x10.json","w"))

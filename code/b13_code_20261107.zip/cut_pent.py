"""同じ面に乗る円環の中心が、平面の第一層の 5 つの円環の中心と同じ形（正五角形）を、何倍の大きさで作るか。"""
import itertools
from collections import Counter
from zphi import Z, dot
import cut_tiling as T
P = Z(0, 1)
R2 = T.R2
base = R2 * (P + 2)                 # 平面の第一層：隣の円環の中心どうしの距離² ＝ (φ＋2)×半径²
res = Counter()
for h, rs in T.rings_by_plane.items():
    cs = [tuple(sum((T.sh(T.c2of(n))[t] for n in r), Z()) for t in range(3)) for r in rs]
    for five in itertools.combinations(range(len(cs)), 5):
        pts = [cs[i] for i in five]
        d = Counter(T.d2(a, b) for a, b in itertools.combinations(pts, 2))
        if len(d) != 2 or sorted(d.values()) != [5, 5]: continue
        a, b = sorted(d, key=lambda z: z.a + 1.618 * z.b)
        if b != a * P * P: continue          # 正五角形（対角² ＝ φ²×辺²）
        k = None; pw = Z(1)
        for e in range(0, 12):
            if a == base * pw: k = e
            pw = pw * P
        res[k] += 1
print("同じ面の円環 5 つの中心が正五角形になる組：大きさ（辺² ＝ 第一層の辺² × φ^k の k）ごとの数", dict(res))

import json, itertools
from fractions import Fraction as F
from collections import Counter
from zphi import Z, GEN, dot
import cp2_ico as I
B = I.B
icos = [(p, s) for (p, n), (o, s) in zip(I.clusters, I.ok) if o]
fr = Counter(tuple(F(x, 12) - (F(x, 12).numerator // F(x, 12).denominator) for x in s) for p, s in icos)
print("中心（塊の基点の座標で）の端数の種類:", {tuple(str(v) for v in k): n for k, n in fr.items()})
# 塊の中心は 基点 + 1/2·(1,...,1)。正二十面体の中心を「塊の中心」の座標で見る
fr2 = Counter(tuple(str((F(x, 12) + F(1, 2)) % 1) for x in s) for p, s in icos)
print("中心（30面体の中心の座標で）の端数の種類:", dict(fr2))
# 中心は窓に入る格子点（タイリングの頂点）か
pts = set(tuple(x) for x in json.load(open("cp2_tiling.json"))["pts"])
cen_v = []
for p, s in icos:
    c = tuple(F(x, 12) + F(1, 2) for x in s)
    if all(v.denominator == 1 for v in c):
        cen_v.append(tuple(int(v) for v in c))
print("中心がタイリングの頂点（窓に入る格子点）:", sum(1 for c in cen_v if c in pts), "/", len(icos), "（中心が整数の組:", len(cen_v), "）")
# H3 正二十面体どうし
sh = Counter(len(a & b) for (a, _), (b, _) in itertools.combinations(icos, 2))
print("H3 正二十面体どうしが共有する塊の数:", dict(sorted(sh.items())))
def d2(a, b):
    v = tuple(F(a[t] - b[t], 12) for t in range(6))
    # 12倍したまま距離²を出して 144 で割る代わりに、比較だけなので 12 倍のまま
    x = tuple(sum((GEN[k][t] * (a[k] - b[k]) for k in range(6)), Z()) for t in range(3))
    return dot(x, x)
dc = Counter(d2(a, b) for (_, a), (_, b) in itertools.combinations(icos, 2))
near = sorted(dc.items(), key=lambda kv: kv[0].a + 1.618034 * kv[0].b)[:6]
print("   中心どうしの距離²（×144、近い順）:", [(str(k), v) for k, v in near])

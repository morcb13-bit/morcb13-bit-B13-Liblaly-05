import itertools
from collections import Counter
from zphi import Z, dot
import cp3_shadow as C
rs = list(C.ringsh)
# 正の対照：輪 1 つの型
C.find([C.tmpl[0]], "正の対照 輪 1 つ")
# タイリングの中の、平行な輪どうしの影の関係
def cen(s):
    return tuple(sum((x[t] for x in s), Z()) for t in range(3))
def d2(a, b): v = tuple(a[t] - b[t] for t in range(3)); return dot(v, v)
rel = Counter()
for a, b in itertools.combinations(rs, 2):
    rel[(len(a & b), str(d2(cen(a), cen(b))))] += 1
T = [frozenset(C.shadow(x) for x in r) for r in C.tmpl]
trel = Counter((len(a & b), str(d2(cen(a), cen(b)))) for a, b in itertools.combinations(T, 2))
print("平面の第一層の輪どうし（影の共有点の数, 影の中心どうしの距離²×100）:", dict(trel))
near = sorted(rel.items(), key=lambda kv: Z(*map(int, kv[0][1].replace('φ','').split('+'))).a if False else 0)
print("タイリングの平行な輪どうし（影の共有点が 1 以上の組）:", {k: v for k, v in rel.items() if k[0] > 0})
small = sorted(rel.items(), key=lambda kv: float(eval(kv[0][1].replace('φ','*1.6180339887'))))[:6]
print("タイリングの平行な輪どうし（中心の近い順）:", small)

import json, cp1_patch as P
H=json.load(open("helix5x10.json"))
for kk in (1,2):
    o=[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
    for nu in (6,7,8,9):
        P.judge("紐 %d°・輪 %d 個"%(72*kk,nu),P.chain(kk,o["Q"],nu))

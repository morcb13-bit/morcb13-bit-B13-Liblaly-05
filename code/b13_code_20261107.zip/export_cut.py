"""図のための書き出し：φ 倍に広がった円環 5 つの組が乗る面の切り口。小数は図のためだけ。"""
import itertools, json, math
from collections import Counter
from zphi import Z, GEN, dot
import cut_tiling as T
import cut_plane as CP
P = Z(0, 1); PH = (1 + 5 ** .5) / 2
f = lambda z: z.a + z.b * PH
A = GEN[2]
base = T.R2 * (P + 2)
found = None
for h, rs in T.rings_by_plane.items():
    cs = [tuple(sum((T.sh(T.c2of(n))[t] for n in r), Z()) for t in range(3)) for r in rs]
    for five in itertools.combinations(range(len(cs)), 5):
        pts = [cs[i] for i in five]
        d = Counter(T.d2(a, b) for a, b in itertools.combinations(pts, 2))
        if len(d) != 2 or sorted(d.values()) != [5, 5]: continue
        a, b = sorted(d, key=lambda z: z.a + 1.618 * z.b)
        if b == a * P * P and a == base * P * P:
            found = (h, [rs[i] for i in five]); break
    if found: break
h, five = found
ringset = [set(r) for r in five]
# 面の上の正五角形すべて
Af = [f(x) for x in A]; nA = math.sqrt(sum(x * x for x in Af)); w = [x / nA for x in Af]
p0 = [f(x) for x in GEN[0]]; d = sum(p0[i] * w[i] for i in range(3)); u = [p0[i] - d * w[i] for i in range(3)]
nu = math.sqrt(sum(x * x for x in u)); u = [x / nu for x in u]
v = [w[1] * u[2] - w[2] * u[1], w[2] * u[0] - w[0] * u[2], w[0] * u[1] - w[1] * u[0]]
to2 = lambda p: [sum(f(p[i]) / 2 * u[i] for i in range(3)), sum(f(p[i]) / 2 * v[i] for i in range(3))]
pents = []
for n, side in T.planes[h]:
    on, cr = CP.section(T.c2of(n), h)
    assert cr == 0 and CP.regular_pentagon(on)
    q = [to2(p) for p in on]
    cx = sum(x for x, y in q) / 5; cy = sum(y for x, y in q) / 5
    q.sort(key=lambda p: math.atan2(p[1] - cy, p[0] - cx))
    ring = next((i for i, r in enumerate(ringset) if n in r), -1)
    pents.append({"q": [[round(x, 4), round(y, 4)] for x, y in q], "r": ring, "s": 1 if side == "上の段" else 0})
# 組の中心と、各円環の中心
rc = []
for r in ringset:
    pts = [to2(T.c2of(n)) for n in r]
    rc.append([sum(p[0] for p in pts) / 10, sum(p[1] for p in pts) / 10])
gc = [sum(c[0] for c in rc) / 5, sum(c[1] for c in rc) / 5]
for p in pents:
    p["q"] = [[round(x - gc[0], 4), round(y - gc[1], 4)] for x, y in p["q"]]
rc = [[c[0] - gc[0], c[1] - gc[1]] for c in rc]
# 縮めたとき（円環の中心を 1/φ 倍に寄せる）に、隣の円環の五角形が重なり合うか
def moved(p, s):
    c = rc[p["r"]]; return [[x - (1 - s) * c[0], y - (1 - s) * c[1]] for x, y in p["q"]]
ring_p = [p for p in pents if p["r"] >= 0]
coin = 0; overl = 0
for a, b in itertools.combinations(ring_p, 2):
    if a["r"] == b["r"]: continue
    A_ = moved(a, 1 / PH); B_ = moved(b, 1 / PH)
    ca = [sum(x for x, y in A_) / 5, sum(y for x, y in A_) / 5]; cb = [sum(x for x, y in B_) / 5, sum(y for x, y in B_) / 5]
    dd = math.hypot(ca[0] - cb[0], ca[1] - cb[1])
    if dd < 1e-6:
        same = sorted(map(tuple, [[round(x, 5), round(y, 5)] for x, y in A_])) == sorted(map(tuple, [[round(x, 5), round(y, 5)] for x, y in B_]))
        coin += 1 if same else 0; overl += 0 if same else 1
print("面の正五角形", len(pents), "／円環の五角形", len(ring_p), "／1/φ 倍に寄せたとき、隣の円環の五角形がぴったり重なる組", coin, "・中心だけ重なり向きが違う組", overl)
R = max(math.hypot(*xy) for p in pents for xy in p["q"])
json.dump({"pents": pents, "rc": [[round(x, 4), round(y, 4)] for x, y in rc], "phi": PH}, open("cut_data.json", "w"), separators=(",", ":"))
print("範囲", round(R, 2), "／書き出し", len(json.dumps(pents)) // 1024, "KB")

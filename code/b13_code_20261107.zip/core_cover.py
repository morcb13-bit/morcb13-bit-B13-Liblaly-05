"""芯の直線のうち、30面体の内部にある部分がつながっているか（すき間の数）。"""
import json, functools
from zphi import *
import core_hollow as C
def cover(name,k,Q,turns=3):
    h=C.screw(k,tuple(Q)); U=C.U
    us=[list(U)]
    for _ in range(5*turns-1): us.append([h(x) for x in us[-1]])
    allc=sorted(set(x for u in us for x in u))
    o=[U[0]]
    for _ in range(4): o.append(h(o[-1]))
    P0=tuple(sum(x[t] for x in o) for t in range(6))
    iv=[C.interval(P0,tuple(5*c[t] for t in range(6)),5) for c in allc]
    iv=[v for v in iv if v not in (None,"all")]
    cmp=lambda a,b: -1 if a<b else (1 if b<a else 0)
    iv.sort(key=functools.cmp_to_key(lambda x,y: cmp(x[0],y[0])))
    gaps=0; touch=0; hi=iv[0][1]
    for lo,h2 in iv[1:]:
        if hi<lo: gaps+=1
        elif not (lo<hi): touch+=1       # 端どうしがちょうど接する
        if hi<h2: hi=h2
    print("%s：芯を通る区間 %d 本、すき間 %d、端で接するだけの継ぎ目 %d"%(name,len(iv),gaps,touch))
H=json.load(open("helix5x10.json"))
pick=lambda kk:[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
cover("72°ずつずらす",1,pick(1)["Q"])
cover("144°ずつずらす",2,pick(2)["Q"])

import json
from zphi import *
import ring5x10 as R
U,g,apply,mpow,A,perp=R.U,R.g,R.apply,R.mpow,R.A,R.perp
def screw(k,Q):
    gk=mpow(g,k); return lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
def units(h,n):
    us=[list(U)]
    for _ in range(n-1): us.append([h(x) for x in us[-1]])
    return us
H=[o for o in json.load(open("helix5x10.json")) if o["share"]==2 and o["ov"]==0]
flat=[o for o in json.load(open("ring5x10_cands.json")) if o["n"]==40 and o["ov"]==10]
def shadow(cs):
    # 真上からの影：軸に垂直な成分（芯の位置は揃えない＝同じ U から出発しているので比べられる）
    return {perp(phys(c)) for c in cs}
# 逆にたどる対の確認
def inv(k,Q):
    gi=mpow(g,(5-k)%5); q=apply(gi,tuple(Q)); return (5-k)%5, tuple(-v for v in q)
keys={(o["k"],tuple(o["Q"])) for o in H}
pairs=sum(1 for o in H if inv(o["k"],o["Q"]) in keys)
print("ずらして閉じる置き方 %d 個のうち、逆にたどると互いに写り合うもの %d 個"%(len(H),pairs))
for o in H:
    h=screw(o["k"],tuple(o["Q"]))
    us=units(h,5)
    one=set(x for u in us for x in u)
    sh=shadow(one)
    hs={}
    for x in one: hs.setdefault(dot(phys(x),A),0); hs[dot(phys(x),A)]+=1
    match=[]
    for f in flat:
        match.append(shadow([tuple(c) for c in f["centers6"]])==sh)
    print("k=%d Q=%s 一周の30面体 %d・影の点 %d・平面40個の置き方の影と一致 %s・高さの段 %d"
          %(o["k"],o["Q"],len(one),len(sh),match,len(hs)))

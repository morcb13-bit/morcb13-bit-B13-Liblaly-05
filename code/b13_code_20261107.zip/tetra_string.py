#  tetra_string.py  正四面体を面でつないだ紐（2026-10-06 の pair2n の作り直し）
#
#      新しい頂点 ＝ いちばん古い頂点を、残り 3 頂点がつくる面で折り返したもの。
#      座標は分数（Fraction）のまま。浮動小数は使わない。
#
#      検定（期待値は 2026-10-06 の記録。走らせる前に置いた値）
#        WA  3 次元の紐は 1〜299 段で、最初の正四面体をずらしただけの形に戻らない
#            対照：立方体を面でつないだ紐は 1 段目で戻る（閉じる側が返ってくる）
#        WB  特性多項式 3x⁴−2x³−2x²−2x+3 ＝ (x−1)²(3x²+4x+3)
#            軸の方向の進みは 1 種類、横の成分の長さも 1 種類、3×（隣の内積）＝ −2×（長さ²）
#        WC  1a の巻きの符号は −、鏡に映した 1b は ＋
#        LP  1a と 1b の横の成分を足すと一本の線の上に乗り、振幅×3ⁿ は 0,1,−4,7,8,−95,308,−377,…
#            y(n+1) ＝ −4y(n) − 9y(n−1)
#        RT  もと来た道：前へ 50・300 段、折り返して同じ段数で最初の正四面体にぴったり戻る

from fractions import Fraction as F

def add(a, b): return tuple(x + y for x, y in zip(a, b))
def sub(a, b): return tuple(x - y for x, y in zip(a, b))
def sc(k, a): return tuple(k * x for x in a)
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b): return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
def det3(a, b, c): return dot(a, cross(b, c))

def refl(p, a, b, c):
    """点 p を平面 abc で折り返す（厳密）"""
    n = cross(sub(b, a), sub(c, a))
    t = F(2 * dot(sub(p, a), n), dot(n, n))
    return sub(p, sc(t, n))

T0 = [tuple(F(x) for x in p) for p in [(0, 0, 0), (1, 1, 0), (1, 0, 1), (0, 1, 1)]]

def string(start, steps):
    v = list(start)
    for _ in range(steps):
        v.append(refl(v[-4], v[-3], v[-2], v[-1]))
    return v

def same_shape_shifted(P, Q):
    """Q が P を平行移動しただけか（頂点の対応は問わない）"""
    for q0 in Q:
        d = sub(q0, P[0])
        if {add(p, d) for p in P} == set(Q):
            return True
    return False

def main():
    ok = {}
    # ---- WA
    v = string(T0, 300)
    first = v[0:4]
    hit = [n for n in range(1, 300) if same_shape_shifted(first, v[n:n+4])]
    e2 = {dot(sub(v[i], v[j]), sub(v[i], v[j])) for n in range(300) for i in range(n, n+4) for j in range(i+1, n+4)}
    ok["WA"] = (hit == [])
    print("WA 1〜299 段で戻る段:", hit or "なし", "／辺の長さ² の種類", sorted(e2), "→", "OK" if ok["WA"] else "NG")
    # 対照：立方体の紐（面で隣へ平行移動するだけ）
    cube = [tuple(F(x) for x in (i, j, k)) for i in (0, 1) for j in (0, 1) for k in (0, 1)]
    nxt = [add(p, (F(1), F(0), F(0))) for p in cube]
    print("   対照 立方体の紐：1 段目で戻る", same_shape_shifted(cube, nxt))

    # ---- WB：重心の歩みと軸
    g = [sc(F(1, 4), add(add(v[n], v[n+1]), add(v[n+2], v[n+3]))) for n in range(296)]
    s = [sub(g[n+1], g[n]) for n in range(295)]
    # 漸化式 v(n+1) = (2/3)(v(n)+v(n-1)+v(n-2)) − v(n-3) の特性多項式 3x⁴−2x³−2x²−2x+3
    # (x−1)² ＝ x²−2x+1 と 3x²+4x+3 の積を整数で展開して一致を見る
    prod = [0]*5
    for i, a in enumerate([1, -2, 1]):
        for j, b in enumerate([3, 4, 3]):
            prod[i+j] += a*b
    ok_poly = prod == [3, -2, -2, -2, 3]
    axis = add(add(sc(3, s[2]), sc(4, s[1])), sc(3, s[0]))        # 3s(n+2)+4s(n+1)+3s(n) は軸の方向に揃う
    along = {F(dot(x, axis)) for x in s}
    perp = [sub(sc(dot(axis, axis), x), sc(dot(x, axis), axis)) for x in s]
    plen = {dot(p, p) for p in perp}
    rot = all(3 * dot(perp[n], perp[n+1]) == -2 * dot(perp[n], perp[n]) for n in range(200))
    ok["WB"] = ok_poly and len(along) == 1 and len(plen) == 1 and rot
    print("WB 特性多項式の割れ方", ok_poly, "／軸の進み", len(along), "種類／横の長さ", len(plen), "種類／3×内積＝−2×長さ²", rot,
          "→", "OK" if ok["WB"] else "NG")

    # ---- WC と LP
    tw = lambda P: {(lambda d: (d > 0) - (d < 0))(det3(P[i], P[i+1], axis)) for i in range(40)}
    nrm = perp[0]
    mir = lambda x: sub(x, sc(F(2 * dot(x, nrm), dot(nrm, nrm)), nrm))
    pb = [mir(x) for x in perp]
    wa, wb = tw(perp), tw(pb)
    ok["WC"] = wa == {-1} and wb == {1}
    print("WC 巻きの符号 1a", wa, " 1b", wb, "→", "OK" if ok["WC"] else "NG")
    lp = [add(x, y) for x, y in zip(perp, pb)]
    ref = lp[1]
    on_line = all(dot(x, nrm) == 0 for x in lp) and all(cross(ref, x) == (0, 0, 0) for x in lp)
    amp = [F(dot(x, ref), dot(ref, ref)) * 3**n for n, x in enumerate(lp[:12])]
    # 最初の振幅が 0、次が 1 になるように基準をそろえる
    base = amp[1]
    y = [a / base for a in amp]
    rec = all(y[n+1] == -4*y[n] - 9*y[n-1] for n in range(1, 11))
    ok["LP"] = on_line and rec and [int(t) for t in y[:8]] == [0, 1, -4, 7, 8, -95, 308, -377]
    print("LP 一本の線の上", on_line, "／振幅×3ⁿ", [int(t) for t in y[:10]], "／漸化式", rec,
          "→", "OK" if ok["LP"] else "NG")

    # ---- RT：もと来た道
    def back(seq, k):
        w = list(seq)
        for _ in range(k):
            # 最新の頂点を、その前の 3 頂点がつくる面で折り返すと、一段前の最古の頂点に戻る
            w.insert(0, refl(w[3], w[0], w[1], w[2]))
            w.pop()
        return w[:4]
    rt = all(back(string(T0, k)[k:k+4], k) == T0 for k in (50, 300))
    ok["RT"] = rt
    print("RT 前へ 50・300 段 → 戻すと最初の正四面体", "OK" if rt else "NG")

    print("\n総合", "OK" if all(ok.values()) else "NG", ok)

if __name__ == "__main__":
    main()

"""図のための書き出し：正二十面体の集まり 1 つ（30面体12個）と、その 6 つの輪、最寄りの集まり。小数は図のためだけ。"""
import json, itertools
from fractions import Fraction as F
from zphi import Z, GEN, dot, cross
import cp2_ico as I
PH = (1 + 5 ** .5) / 2
f = lambda z: z.a + z.b * PH
icos = [(sorted(p), s) for (p, n), (o, s) in zip(I.clusters, I.ok) if o]
G = [[f(c) for c in v] for v in GEN]
def ph(v): return [sum(G[k][t] * v[k] for k in range(6)) for t in range(3)]
# 原点にいちばん近い集まりを選ぶ
def cen(s): return [x / 12 + 0.5 for x in s]
k0 = min(range(len(icos)), key=lambda i: sum(x * x for x in ph(cen(icos[i][1]))))
p0, s0 = icos[k0]
c0 = ph(cen(s0))
rt = lambda b: [x - y for x, y in zip(ph([b[t] + 0.5 for t in range(6)]), c0)]
pts = [rt(b) for b in p0]
# 6 つの輪（各軸の両端を除いた 10 個）：対角の組
def d2(a, b): return sum((x - y) ** 2 for x, y in zip(a, b))
axes = []
for i in range(12):
    j = max(range(12), key=lambda j: d2(pts[i], pts[j]))
    if i < j: axes.append([i, j])
# 最寄りの集まり（中心どうし最短）
dmin = min(d2(ph(cen(s)), c0) for _, s in icos if s != s0)
nb = [[rt(b) for b in p] for p, s in icos if s != s0 and abs(d2(ph(cen(s)), c0) - dmin) < 1e-6]
# 30面体の面（中心からの相対、生の座標）
faces = []
for i, j in itertools.combinations(range(6), 2):
    nv = [f(c) for c in cross(GEN[i], GEN[j])]
    for sg in (1, -1):
        nn = [sg * x for x in nv]; c = [0, 0, 0]
        for k in range(6):
            d = sum(G[k][t] * nn[t] for t in range(3))
            if abs(d) < 1e-9: continue
            c = [c[t] + G[k][t] * (.5 if d > 0 else -.5) for t in range(3)]
        u = [x * .5 for x in G[i]]; v = [x * .5 for x in G[j]]
        q = [[c[t] - u[t] - v[t] for t in range(3)], [c[t] + u[t] - v[t] for t in range(3)],
             [c[t] + u[t] + v[t] for t in range(3)], [c[t] - u[t] + v[t] for t in range(3)]]
        L = sum(x * x for x in nn) ** .5
        faces.append({"q": [[round(x, 4) for x in P] for P in q], "n": [round(x / L, 4) for x in nn]})
r = lambda a: [round(x, 4) for x in a]
D = {"faces": faces, "pts": [r(p) for p in pts], "axes": axes, "nb": [[r(p) for p in c] for c in nb]}
print("集まり", len(pts), "軸", len(axes), "最寄りの集まり", len(nb))
json.dump(D, open("ico_data.json", "w"), separators=(",", ":"))

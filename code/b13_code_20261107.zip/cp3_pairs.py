import itertools
from collections import Counter
from zphi import Z, dot
import cp3_shadow as C
rs = list(C.ringsh)
def cen(s): return tuple(sum((x[t] for x in s), Z()) for t in range(3))
def d2(a, b): v = tuple(a[t] - b[t] for t in range(3)); return dot(v, v)
R2 = Z(7200, 11600)
P = Z(0, 1)
hd = Counter(); same_rt = 0; ratio_ok = 0; n = 0
for a, b in itertools.combinations(rs, 2):
    if len(a & b) != 2: continue
    n += 1
    if d2(cen(a), cen(b)) == R2 * P * P: ratio_ok += 1
    ra, rb = C.ringsh[a][0], C.ringsh[b][0]
    for s in a & b:
        xa = [x for x in ra if C.shadow(x) == s][0]; xb = [x for x in rb if C.shadow(x) == s][0]
        if xa == xb: same_rt += 1
        hd[str(abs(C.height(xa) - C.height(xb)))] += 1
print("影を 2 点共有する平行な輪の組:", n, "／中心どうしの距離 ＝ φ×輪の半径:", ratio_ok)
print("共有する影の点で、同じ30面体:", same_rt, "／真上に重なる30面体どうしの高さの差（×|A|²）:", dict(hd))
print("参考 輪の中の上の段と下の段の高さの差（×|A|²）: 2+4φ")

#  c1_core_nd.py  検定C1：n 次元の正単体と鏡像の芯は正軸体（直交する ± の n 対）になるか（2026-10-10 の作り直し）
#      正単体を (n＋1) 座標の和 0 の面に置く：正単体＝各座標 ≥ −1、鏡像＝各座標 ≤ 1。芯の頂点は ＋1・−1・0 の列。
#      期待値：芯＝正軸体は n＝1・3。芯の中に直交する n 対が入るのは n＝1・3・7。n＝5 は直交する対の組が一つもない
def core(n):
    m = n + 1; out = set()
    for free in range(m):
        others = [j for j in range(m) if j != free]
        for mask in range(1 << n):
            x = [0] * m; s = 0
            for k, j in enumerate(others):
                v = -1 if mask >> k & 1 else 1; x[j] = v; s += v
            x[free] = -s
            if -1 <= x[free] <= 1: out.add(tuple(x))
    return sorted(out)
def analyse(n):
    V = core(n); S = set(V); P = []; seen = set()
    for v in V:
        w = tuple(-x for x in v)
        if v in seen or w not in S: continue
        P.append(v); seen |= {v, w}
    G = [[sum(a*b for a, b in zip(p, q)) for q in P] for p in P]
    nz = sum(1 for i in range(len(P)) for j in range(i+1, len(P)) if G[i][j] != 0)
    adj = [{j for j in range(len(P)) if j != i and G[i][j] == 0} for i in range(len(P))]
    best = 0
    def grow(cl, cand):
        nonlocal best
        best = max(best, len(cl))
        if best >= n: return
        for c in sorted(cand):
            if cl and c < cl[-1]: continue
            grow(cl + [c], cand & adj[c])
    grow([], set(range(len(P))))
    orth_pairs = sum(1 for i in range(len(P)) for j in range(i+1, len(P)) if G[i][j] == 0)
    return len(V), len(P), nz, best, orth_pairs, (len(V) == 2*n and len(P) == n and nz == 0)
rows = {n: analyse(n) for n in range(1, 8)}
print(" n  芯の頂点  ±の対  非直交の組  直交最大  直交する対の組  芯＝正軸体")
for n, r in rows.items():
    print("%2d  %7d  %5d  %9d  %7d  %13d   %s" % (n, r[0], r[1], r[2], r[3], r[4], "OK" if r[5] else "NG"))
cross = [n for n, r in rows.items() if r[5]]
inside = [n for n, r in rows.items() if r[3] >= n]
ok = cross == [1, 3] and [n for n in inside if n % 2] == [1, 3, 7] and rows[5][4] == 0
print("芯＝正軸体", cross, "／中に直交する n 対（奇数）", [n for n in inside if n % 2], "／n=5 の直交する組", rows[5][4])
print("総合", "OK" if ok else "NG")

import json
from collections import Counter
from zphi import *
import ring5x10 as R
U,g,apply,mpow,A,perp=R.U,R.g,R.apply,R.mpow,R.A,R.perp
def screw(k,Q):
    gk=mpow(g,k); return lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
def oneturn(k,Q):
    h=screw(k,Q); us=[list(U)]
    for _ in range(4): us.append([h(x) for x in us[-1]])
    return sorted(set(x for u in us for x in u))
def sig(cs):
    pts=list({perp(phys(c)) for c in cs}); n=len(pts)
    cen=tuple(sum((p[t] for p in pts),Z()) for t in range(3))
    rel=[tuple(n*p[t]-cen[t] for t in range(3)) for p in pts]       # n倍して芯から測る
    rad=Counter(dot(q,q) for q in rel)
    pair=Counter(dot(tuple(a[t]-b[t] for t in range(3)),tuple(a[t]-b[t] for t in range(3))) for i,a in enumerate(pts) for b in pts[i+1:])
    return n,frozenset(rad.items()),frozenset(pair.items())
H=[o for o in json.load(open("helix5x10.json")) if o["share"]==2 and o["ov"]==0]
F=[o for o in json.load(open("ring5x10_cands.json")) if o["n"]==40 and o["ov"]==10]
fs={sig([tuple(c) for c in f["centers6"]]) for f in F}
print("平面40個（食い込み10）の置き方の影の型:",len(fs))
hs=Counter(sig(oneturn(o["k"],tuple(o["Q"]))) for o in H)
print("ずらして閉じる置き方の影の型:",len(hs))
for s,c in hs.items():
    print("  件数",c,"影の点",s[0],"平面40個の影と同じ型:", s in fs)
# 影の中の5回対称の芯：芯のまわりの半径²の種類と個数（平面と同じ形で表示）
o=H[0]; cs=oneturn(o["k"],tuple(o["Q"]))
pts=list({perp(phys(c)) for c in cs}); n=len(pts)
cen=tuple(sum((p[t] for p in pts),Z()) for t in range(3))
cnt=Counter(dot(q,q) for q in [tuple(n*p[t]-cen[t] for t in range(3)) for p in pts])
print("芯からの半径²（×n²|A|⁴）と個数:",sorted(cnt.items(),key=lambda kv:kv[0].a+1.618*kv[0].b))
# 同じ影に重なる2個（真上に重なる30面体）の高さの差
from itertools import combinations
for a,b in combinations(cs,2):
    if perp(phys(a))==perp(phys(b)):
        print("真上に重なる組 高さ",dot(phys(a),A),dot(phys(b),A))
print("影の型ごとの回転の段 k と1歩の高さ:")
byt={}
for o in H:
    s=sig(oneturn(o["k"],tuple(o["Q"])))
    h=screw(o["k"],tuple(o["Q"]))
    step=dot(phys(h(U[0])),A)-dot(phys(U[0]),A)
    byt.setdefault(s,Counter())[(o["k"],str(step))]+=1
for i,(s,c) in enumerate(byt.items()): print("  型",i+1,dict(c))

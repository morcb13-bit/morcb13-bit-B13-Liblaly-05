"""core_hollow.py ── 紐の芯（5回のねじれの軸）に中空があるか。Z[φ] の整数だけ。
問1 芯の直線が、どれかの30面体の内部を通るか（通らなければ芯は空いている）
問2 同じ大きさの30面体を芯に沿って滑らせたとき、どこかで食い込むか（食い込まなければ30面体1個が通る太さ）
対照 30面体の中心を通る直線は必ず問1で「通る」と出ること"""
import json
from zphi import *
import ring5x10 as R
U,g,apply,mpow,A=R.U,R.g,R.apply,R.mpow,R.A
def screw(k,Q):
    gk=mpow(g,k); return lambda x: tuple(apply(gk,x)[t]+Q[t] for t in range(6))
class Fr:                       # Z[φ] の分数 a/b
    def __init__(s,a,b): s.a,s.b=(a,b) if b.sign()>0 else (-a,-b)
    def __lt__(s,o): return (s.a*o.b - o.a*s.b).sign()<0
    def __le__(s,o): return (s.a*o.b - o.a*s.b).sign()<=0
def interval(P0,C5,lim):
    """直線 (P0+tA)/5 が |((P0+tA)/5 − C5/5)·n| < lim/10 を満たす t の開区間（なければ None）"""
    lo=hi=None
    d=phys(tuple(P0[t]-C5[t] for t in range(6)))
    for n,h in zip(NRM,H2):
        u=dot(d,n)*2; s=dot(A,n)*2; L=h*lim
        if s.sign()==0:
            if not ((abs(u)-L).sign()<0): return None
            continue
        a,b=Fr(-L-u,s),Fr(L-u,s)
        if b<a: a,b=b,a
        lo=a if lo is None or lo<a else lo
        hi=b if hi is None or b<hi else hi
    if lo is None: return "all"
    return (lo,hi) if lo<hi else None
def test(name,k,Q,turns=3):
    h=screw(k,tuple(Q))
    us=[list(U)]
    for _ in range(5*turns-1): us.append([h(x) for x in us[-1]])
    allc=sorted(set(x for u in us for x in u))
    o=[U[0]]
    for _ in range(4): o.append(h(o[-1]))
    P0=tuple(sum(x[t] for x in o) for t in range(6))
    C5=lambda c: tuple(5*c[t] for t in range(6))
    hit1=[c for c in allc if interval(P0,C5(c),5) is not None]
    hit2=[c for c in allc if interval(P0,C5(c),10) is not None]
    # 芯からいちばん近い30面体
    AA=dot(A,A)
    def r2(c):
        d=phys(tuple(5*c[t]-P0[t] for t in range(6)))
        q=tuple(AA*d[t]-dot(d,A)*A[t] for t in range(3)); return dot(q,q)
    rs=sorted({r2(c) for c in allc},key=lambda z:z.a+1.618034*z.b)
    print("%s：30面体 %d 個／芯の直線が内部を通る30面体 %d 個／芯に沿って滑らせた30面体と食い込む30面体 %d 個"
          %(name,len(allc),len(hit1),len(hit2)))
    print("   芯からの水平距離²の小さい順（×25·|A|⁴）:",rs[:3])
    return P0,allc
H=json.load(open("helix5x10.json"))
F=[o for o in json.load(open("ring5x10_cands.json")) if o["n"]==40 and o["ov"]==10][0]
pick=lambda kk:[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
test("平面のまま閉じる（参考）",F["k"],F["Q"],turns=1)
test("72°ずつずらす",1,pick(1)["Q"])
test("144°ずつずらす",2,pick(2)["Q"])
# 対照：30面体の中心を通る直線（芯の代わりに U[0] の中心を通す）
c=U[0]; P0=tuple(5*c[t] for t in range(6))
print("対照：30面体の中心を通る直線 →", "通る" if interval(P0,P0,5) is not None else "通らない（判定が壊れている）")
# 対照2：その30面体の外側すれすれ（面接触の一歩の先）を通る直線は、その30面体を通らない
far=tuple(5*(c[t]+3*R.U[1][t]-3*c[t]) for t in range(6))
print("対照：遠く離れた直線 →", "通る（判定が壊れている）" if interval(far,P0,5) is not None else "通らない")

#  t1_time_split.py  検定T1：中にできる形を「時刻の中（最後の座標がそろう）」と「時間をまたぐ」に分ける（2026-10-10 の作り直し）
#      k ＝ n を 2 で割った商。期待値（走らせる前に K1 から引き算で置いた値）：n＝3 は 4＋12、n＝5 は 24＋96
from itertools import product
def inner(n, k):
    V = [tuple(v) for v in product((1, -1), repeat=n)]; S = set(V); seen = set(); out = []
    for v0 in V:
        D = [tuple(w[i] - v0[i] for i in range(n)) for w in V if w != v0]
        def grow(ch, st):
            if len(ch) == k:
                pts = []
                for m in range(1 << k):
                    p = list(v0)
                    for j in range(k):
                        if m >> j & 1: p = [p[i] + ch[j][i] for i in range(n)]
                    pts.append(tuple(p))
                if all(p in S for p in pts) and sum(x*x for x in ch[0]) > 4:
                    key = frozenset(pts)
                    if key not in seen: seen.add(key); out.append(pts)
                return
            for i in range(st, len(D)):
                a = D[i]
                if ch and sum(x*x for x in a) != sum(x*x for x in ch[0]): continue
                if all(sum(x*y for x, y in zip(a, c)) == 0 for c in ch): grow(ch + [a], i + 1)
        grow([], 0)
    still = sum(1 for pts in out if len({p[-1] for p in pts}) == 1)
    return still, len(out) - still
r = {n: inner(n, n // 2) for n in (3, 5)}
ok = r == {3: (4, 12), 5: (24, 96)}
print("n=3 時刻の中＋時間をまたぐ", r[3], "／n=5", r[5], "→", "OK" if ok else "NG")

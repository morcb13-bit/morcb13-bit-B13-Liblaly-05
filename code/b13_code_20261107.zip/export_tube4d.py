"""図のための書き出し：600胞体の大円の十角形 D と、そのまわりの五角形 10 段の管（50 頂点）。小数は図のためだけ。"""
import json, math, itertools
import tube4d as T
PH = (1 + 5 ** .5) / 2
f = lambda z: z.a + z.b * PH
idx = T.idx
D = [[f(x) for x in d] for d in T.D]
Dp = [[f(x) for x in d] for d in T.Dp]
L = T.layers
verts = []; lay = []
for k in range(10):
    for v in L[k]: verts.append([f(x) for x in v]); lay.append(k)
vid = {tuple(v): i for i, v in enumerate(sum(([v for v in L[k]] for k in range(10)), []))}
allv = sum(([v for v in L[k]] for k in range(10)), [])
edges = [[i, j] for i, j in itertools.combinations(range(len(allv)), 2) if idx[allv[j]] in T.adj[idx[allv[i]]]]
# D の面の正規直交基底（e1,e2）と、D′ の面の基底（e3,e4）
def nrm(v): l = math.sqrt(sum(x * x for x in v)); return [x / l for x in v]
def dotf(a, b): return sum(x * y for x, y in zip(a, b))
e1 = nrm(D[0]); t = D[1]; e2 = nrm([t[i] - dotf(t, e1) * e1[i] for i in range(4)])
e3 = nrm(Dp[0]); t = Dp[1]
e3c = e3
# D′ の中で、D′ の並び順の次の頂点（隣）を選ぶ
nb = min(Dp[1:], key=lambda u: -dotf(u, Dp[0]))
e4 = nrm([nb[i] - dotf(nb, e3) * e3[i] for i in range(4)])
B = [e1, e2, e3, e4]
loc = lambda v: [round(dotf(v, b), 5) for b in B]
out = {"v": [loc(v) for v in verts], "layer": lay, "edges": edges, "D": [loc(d) for d in D], "Dp": [loc(d) for d in Dp]}
json.dump(out, open("tube4d_fig.json", "w"), separators=(",", ":"))
print("頂点", len(verts), "辺", len(edges), "（各頂点 6 本なら 150）")

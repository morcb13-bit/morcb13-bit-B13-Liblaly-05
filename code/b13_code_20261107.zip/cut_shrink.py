import json, math, itertools
D = json.load(open("cut_data.json")); PH = D["phi"]; rc = D["rc"]
ring_p = [p for p in D["pents"] if p["r"] >= 0]
def tf(p, s, rot):
    c = rc[p["r"]]; out = []
    for x, y in p["q"]:
        dx, dy = x - c[0], y - c[1]
        ca, sa = math.cos(rot), math.sin(rot)
        out.append((c[0] * s + dx * ca - dy * sa, c[1] * s + dx * sa + dy * ca))
    return out
def key(q): return tuple(sorted((round(x, 4), round(y, 4)) for x, y in q))
for rotdeg in (0, 36):
    for s in (1 / PH, 1 / PH ** 2):
        Q = [tf(p, s, math.radians(rotdeg)) for p in ring_p]
        ks = Counter = {}
        for p, q in zip(ring_p, Q): ks.setdefault(key(q), set()).add(p["r"])
        shared = sum(1 for v in ks.values() if len(v) > 1)
        # 重なり（中心距離が五角形の内接直径より小さい別の円環の組）
        cs = [((sum(x for x, y in q) / 5, sum(y for x, y in q) / 5), p["r"]) for p, q in zip(ring_p, Q)]
        side = math.dist(ring_p[0]["q"][0], ring_p[0]["q"][1]); inr = side / (2 * math.tan(math.pi / 5))
        clash = sum(1 for (a, ra), (b, rb) in itertools.combinations(cs, 2) if ra != rb and 1e-6 < math.dist(a, b) < 2 * inr - 1e-6)
        print("各円環を自分の中心で %2d° 回し、中心を %.3f 倍に寄せる：ぴったり共有する五角形 %d・食い込む組 %d" % (rotdeg, s, shared, clash))

"""芯の上の「30面体の中」と「中空」の長さの比を Z[φ] で厳密に。"""
import json, functools
from zphi import *
import core_hollow as C
H=json.load(open("helix5x10.json"))
pick=lambda kk:[o for o in H if o["share"]==2 and o["ov"]==0 and o["k"]==kk and (o["pitch"][0]+o["pitch"][1])>0][0]
def sub(x,y): return C.Fr(x.a*y.b-y.a*x.b, x.b*y.b)
def eq(x,y): return (x.a*y.b-y.a*x.b).sign()==0
def run(name,k,Q):
    h=C.screw(k,tuple(Q)); U=C.U; us=[list(U)]
    for _ in range(14): us.append([h(x) for x in us[-1]])
    allc=sorted(set(x for u in us for x in u))
    o=[U[0]]
    for _ in range(4): o.append(h(o[-1]))
    P0=tuple(sum(x[t] for x in o) for t in range(6))
    iv=[C.interval(P0,tuple(5*c[t] for t in range(6)),5) for c in allc]
    iv=[v for v in iv if v not in (None,"all")]
    cmp=lambda a,b:-1 if a<b else (1 if b<a else 0)
    iv.sort(key=functools.cmp_to_key(lambda x,y:cmp(x[0],y[0])))
    ins=[sub(b,a) for a,b in iv]; gap=[sub(iv[i+1][0],iv[i][1]) for i in range(len(iv)-1)]
    print(name,"中の長さが全部同じ:",all(eq(x,ins[0]) for x in ins),
          " 中空の長さが全部同じ:",all(eq(x,gap[0]) for x in gap))
    if not eq(gap[0],C.Fr(Z(0),Z(1))):
        # 中 ÷ 中空 = φ か：中 = φ·中空
        phig=C.Fr(gap[0].a*Z(0,1),gap[0].b)
        print("   中 ＝ φ × 中空:",eq(ins[0],phig))
    return ins[0]
a=run("72°",1,pick(1)["Q"]); b=run("144°",2,pick(2)["Q"])
print("144°の中の長さ ＝ φ × 72°の中の長さ:",eq(b,C.Fr(a.a*Z(0,1),a.b)))
print("144°の中の長さ ＝ 72°の（中＋中空）:", "上の2つから従う" )

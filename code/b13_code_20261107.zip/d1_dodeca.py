#  d1_dodeca.py  検定D1：正十二面体の 20 頂点の中の正四面体・鏡像の対・軸（2026-10-10 の作り直し）
#      頂点は a＋bφ（a, b は整数）だけで持つ：(±1,±1,±1) と (0,±(φ−1),±φ) の巡回。
#      期待値：正四面体 10 個、鏡像（点対称）の対 5 組、各対の芯の軸 3 本ずつで合わせて 15 本（向きはすべて異なる）
#      対照：φ を含む 12 頂点を外して立方体の 8 頂点だけにすると、正四面体 2 個・対 1 組しか残らない
from itertools import combinations, product
from zphi import Z
P = Z(0, 1)
def dot(u, v):
    s = Z()
    for a, b in zip(u, v): s = s + a * b
    return s
def sub(u, v): return tuple(a - b for a, b in zip(u, v))
cube = [tuple(Z(x) for x in s) for s in product((1, -1), repeat=3)]
rest = []
for s1, s2 in product((1, -1), repeat=2):
    a, b = (P - 1) * s1, P * s2
    for c in [(Z(), a, b), (b, Z(), a), (a, b, Z())]: rest.append(c)
def analyse(V, name):
    tets = []
    for q in combinations(V, 4):
        d = {dot(sub(a, b), sub(a, b)) for a, b in combinations(q, 2)}
        if len(d) == 1: tets.append(frozenset(q))
    S = set(tets); pairs = []
    for t in tets:
        m = frozenset(tuple(-x for x in p) for p in t)
        if m in S and m != t and (m, t) not in pairs: pairs.append((t, m))
    # 芯の軸：正四面体の向かい合う辺の中点を結ぶ向き（中点の 2 倍 ＝ 2 頂点の和）
    axes = set()
    for t, m in pairs:
        q = list(t)
        for a, b in combinations(q, 2):
            v = tuple(x + y for x, y in zip(a, b))
            neg = tuple(-x for x in v)
            axes.add(min(v, neg, key=lambda w: tuple((x.a, x.b) for x in w)))
    print("%s：頂点 %d・正四面体 %d・鏡像の対 %d・軸 %d" % (name, len(V), len(tets), len(pairs), len(axes)))
    return len(tets), len(pairs), len(axes)
r = analyse(cube + rest, "正十二面体")
c = analyse(cube, "対照 立方体の8頂点だけ")
print("総合", "OK" if r == (10, 5, 15) and c[:2] == (2, 1) else "NG")
